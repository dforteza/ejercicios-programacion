package Principal;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class Main 
{
	public static void main(String[] args) 
	{
		String paises[] = {"Japón", "Sudáfrica", "Canadá", "Brasil",
				"Australia", "Argentina", "India" ,"Dinamarca"};
		
		String capitales[] = {"Tokio", "Pretoria", "Ottawa", "Brasilia",
				"Camberra", "Buenos Aires", "Nueva Delhi","Copenhague"};
		
		List<Entidad> listaPaises = new LinkedList<>();
		List<Entidad> listaCapitales = new LinkedList<>();
		
		for (String nombre : paises)
			listaPaises.add(new Entidad(nombre));
		
		for (String nombre : capitales)
			listaCapitales.add(new Entidad(nombre));
		
		System.out.println(listaPaises);
		System.out.println(listaCapitales);
		
		ListIterator litP = listaPaises.listIterator();
		ListIterator litC = listaCapitales.listIterator();
		
		while (litP.hasNext()) // Mientras quedan Paises
		{
			litP.next(); // Avanzo un país
			litP.add(litC.next()); // Añado una capital
			litC.remove(); // Elimino una capital
		}
		
		System.out.println(listaPaises);
		System.out.println(listaCapitales);
	}
}
