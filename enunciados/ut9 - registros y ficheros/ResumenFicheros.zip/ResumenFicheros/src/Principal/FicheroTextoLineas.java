package Principal;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class  FicheroTextoLineas
{
	public  FicheroTextoLineas()
	{
	}
	
	public void leer(String fileName) throws IOException
	{
		FileReader fr = new FileReader(fileName);
		BufferedReader entrada = new BufferedReader(fr);
		String linea;
		while ((linea=entrada.readLine())!=null)
		{
			System.out.println("Leo la línea: "+linea);
		}
		entrada.close();
		fr.close();
	}
	
	public void leerTokens(String fileName,String separador) throws IOException
	{
		FileReader fr = new FileReader(fileName);
		BufferedReader entrada = new BufferedReader(fr);
		String linea;
		String [] tokens;
		while ((linea=entrada.readLine())!=null)
		{
			System.out.println("Leo la línea: "+linea);
			tokens = linea.split(separador);
			for (int i=0;i<tokens.length;i++)
				System.out.println("Token: "+tokens[i]);
		}
		entrada.close();
		fr.close();
	}
	
	
	public void escribir(String fileName,String texto) throws IOException
	{
		FileWriter fw = new FileWriter(fileName);
		BufferedWriter salida = new BufferedWriter(fw);
		salida.write(texto);
		salida.close();
		fw.close();
	}
}

