package Principal;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class FicheroBinarioObjetos 
{
	public FicheroBinarioObjetos ()
	{
	}
	
	public void leer(String fileName) throws IOException
	{
		FileInputStream fis = new FileInputStream(fileName);
		ObjectInputStream entrada = new ObjectInputStream(fis);
		while (true)
		{
			try 
			{
				Alumno alumno = (Alumno) entrada.readObject();
				System.out.println("Leo "+alumno);
			}
			catch (EOFException e)
			{
				System.out.println("Alcanzado EOF");
				break;
			} catch (ClassNotFoundException e) 
			{
				e.printStackTrace();
			}
		}
		entrada.close();
		fis.close();
	}
	
	public void escribir (String fileName, Alumno alumno) throws IOException
	{
		FileOutputStream fos = new FileOutputStream(fileName);
		ObjectOutputStream salida = new ObjectOutputStream(fos);
		salida.writeObject(alumno);
		salida.close();
		fos.close();
	}
	
}
