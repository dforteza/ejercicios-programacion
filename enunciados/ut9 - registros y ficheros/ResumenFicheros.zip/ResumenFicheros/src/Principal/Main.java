package Principal;

import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException 
	{
		FicheroTextoCaracteres ft1 = new FicheroTextoCaracteres();
		FicheroTextoLineas ft2 = new FicheroTextoLineas();
		FicheroTextoTiposSimples ft3 = new FicheroTextoTiposSimples();
		
		FicheroBinarioTipos fb1 = new FicheroBinarioTipos();
		FicheroBinarioObjetos fb2 = new FicheroBinarioObjetos();
		
		System.out.println("FICHEROS DE TEXTO");
		System.out.println("=================");
		
		System.out.println("Vamos a leer el fichero de texto por caracteres");
		ft1.leer("fichero.txt");
		
		System.out.println("Vamos a leer el fichero de texto por líneas");
		ft2.leer("fichero.txt");
		
		System.out.println("Vamos a leer el fichero de texto por tipos simples");
		ft3.leer("fichero.txt");
		
		System.out.println("Vamos a crear los ficheros de salida");
		ft1.escribir("ficheroCaracteres.txt","Esto es un texto de ejemplo 123 78,56");
		ft2.escribir("ficheroLineas", "Esto es un texto de ejemplo 123 78,56");
		ft3.escribir("ficheroTipos.txt","Texto",123,34.56);
		
		System.out.println("FICHEROS DE BINARIOS");
		System.out.println("====================");
		
		fb1.escribir("java.dat","JAVA",2025,3.1415);
		fb2.escribir("alumno.dat",new Alumno (11,"Ana Pérez",9.8));
		fb1.leer("java.dat");
		fb2.leer("alumno.dat");
	}

}
