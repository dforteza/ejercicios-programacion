package Principal;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class  FicheroTextoTiposSimples
{
	public  FicheroTextoTiposSimples()
	{
	}
	
	public void leer(String fileName) throws IOException
	{
		FileReader fr = new FileReader(fileName);
		Scanner entrada = new Scanner(fr);
		int entero;
		double real;
		String texto;
		while (entrada.hasNextLine())
		{
			if (entrada.hasNextInt())
			{
				entero= entrada.nextInt();
				System.out.println("Leo un número entero:"+entero);
			}
			else
				if (entrada.hasNextDouble())
				{
					real= entrada.nextDouble();
					System.out.println("Leo un número real:"+real);
				}
				else
					if (entrada.hasNext())
					{
						texto=entrada.next();
						System.out.println("Leo una palabra: "+texto);
					}
					else
						entrada.nextLine();
		}
		entrada.close();
		fr.close();
	}
	
	public void escribir(String fileName,String texto, int entero,double real) throws IOException
	{
		FileWriter fw = new FileWriter(fileName);
		PrintWriter salida = new PrintWriter(fw);
		
		salida.println ("Texto "+texto);
		salida.println ("Entero "+entero+" ");
		salida.println ("Real "+real+" ");
		salida.close();
		fw.close();
	}
}

