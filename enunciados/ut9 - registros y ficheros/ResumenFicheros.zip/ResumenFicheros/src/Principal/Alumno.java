package Principal;

import java.io.Serializable;

public class Alumno implements Serializable
{
	private int numeroMatricula;
	private String nombre;
	private double calificacion;
	public Alumno(int numeroMatricula, String nombre, double calificacion) {
		super();
		this.numeroMatricula = numeroMatricula;
		this.nombre = nombre;
		this.calificacion = calificacion;
	}
	public int getNumeroMatricula() {
		return numeroMatricula;
	}
	public void setNumeroMatricula(int numeroMatricula) {
		this.numeroMatricula = numeroMatricula;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public double getCalificacion() {
		return calificacion;
	}
	public void setCalificacion(double calificacion) {
		this.calificacion = calificacion;
	}
	@Override
	public String toString() {
		return "Alumno [numeroMatricula=" + numeroMatricula + ", nombre=" + nombre + ", calificacion=" + calificacion
				+ "]";
	}
}
