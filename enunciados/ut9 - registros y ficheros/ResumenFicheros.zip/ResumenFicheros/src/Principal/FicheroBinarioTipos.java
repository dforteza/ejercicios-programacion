package Principal;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FicheroBinarioTipos
{
	public FicheroBinarioTipos()
	{
	}
	
	public void leer(String fileName) throws IOException
	{
		FileInputStream fis = new FileInputStream(fileName);
		DataInputStream entrada = new DataInputStream(fis);
		while (true)
		{
			try
			{
				String cadena = entrada.readUTF();
				int entero = entrada.readInt();
				double real = entrada.readDouble();
				System.out.println("Leo cadena "+cadena);
				System.out.println("Leo entero "+entero);
				System.out.println("Leo real "+real);
			}
			catch (EOFException e)
			{
				System.out.println("Fin del fichero alcanzado (EOF)");
				break; // Para abandonar el bucle
			}
		}
		entrada.close();
		fis.close();
	}
	
	public void escribir (String fileName,String texto,int entero,double real) throws IOException
	{
		FileOutputStream fos = new FileOutputStream(fileName);
		DataOutputStream salida = new DataOutputStream(fos);
		salida.writeUTF(texto);
		salida.writeInt(entero);
		salida.writeDouble(real);
		salida.close();
		fos.close();
	}
}
