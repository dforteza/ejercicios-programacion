package Principal;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FicheroTextoCaracteres 
{
	private char letra;
	
	public FicheroTextoCaracteres()
	{
	}
	
	public void leer(String fileName) throws IOException
	{
		FileReader entrada = new FileReader(fileName);
		int c;
		while ((c=entrada.read())!=-1)
		{
			letra = (char )c;
			System.out.println("Leo la letra: "+letra);
		}
		entrada.close();
	}
	
	public void escribir(String fileName,String texto) throws IOException
	{
		FileWriter salida = new FileWriter(fileName);
		for (int i=0;i<texto.length();i++)
			salida.write((int)texto.charAt(i)); // Letra a letra

		salida.write(texto); // Admite también el string
		salida.close();
	}
}
