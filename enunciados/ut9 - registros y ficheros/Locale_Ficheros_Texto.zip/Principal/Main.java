package Principal;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) throws IOException 
	{
		Locale spanishSpain = new Locale("es", "ES"); // Español de España
		String linea;
		float pi=3.14159F;
		
		// Escritura del fichero
		FileWriter ficheroW = new FileWriter("fichero.txt");
		PrintWriter salida = new PrintWriter(ficheroW);

		salida.println("Esto es una línea");
		salida.printf(spanishSpain,"%f",pi);
		
		salida.close();
		ficheroW.close();
		
		// Lectura del fichero
		FileReader ficheroR = new FileReader("fichero.txt");
		Scanner entrada = new Scanner(ficheroR);
		entrada.useLocale(spanishSpain);
		
		linea = entrada.nextLine();
		pi = entrada.nextFloat();
		System.out.println(linea+" "+pi);
		entrada.close();
		ficheroR.close();
	}
}
