package Principal.modelo;

public class Auxiliar extends Gestion 
{
	private static int complemento = 100;

	public Auxiliar(String dni, String nombre, float salarioBase, int antiguedad) 
	{
		super(dni, nombre, salarioBase, antiguedad);
		this.setSalarioFinal(salarioBase+complemento);
	}
	
	public String toString()
	{
		String resultado = "";
		resultado += "AUXILIAR:"+super.toString();
		return resultado; 
	}
	
	
}
