package Principal.modelo;

public class Gestion extends Trabajador 
{
	private int antiguedad;

	public Gestion(String dni, String nombre, float salarioBase, int antiguedad) 
	{
		super(dni, nombre, salarioBase);
		this.antiguedad = antiguedad;
	}

	public int getAntiguedad() {
		return antiguedad;
	}

	public void setAntiguedad(int antiguedad) {
		this.antiguedad = antiguedad;
	}
	
	public String toString()
	{
		String resultado ="";
		resultado += super.toString()+" ";
		resultado += this.antiguedad;
		return resultado;
	}
}
