package Principal.modelo;

public class Administrativo extends Gestion 
{
	private static int complemento = 20;

	public Administrativo(String dni, String nombre, float salarioBase, int antiguedad) 
	{
		super(dni, nombre, salarioBase, antiguedad);
		this.setSalarioFinal(salarioBase+antiguedad*complemento);
	}
	
	public String toString()
	{
		String resultado = "";
		resultado += "ADMINISTRATIVO:"+super.toString();
		return resultado; 
	}
	
}
