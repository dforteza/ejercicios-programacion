package Principal.modelo;

public class Analista extends Informatico 
{
	private static float complemento = 0.30F;

	public Analista(String dni, String nombre, float salarioBase, String titulacion) 
	{
		super(dni, nombre, salarioBase, titulacion);
		this.setSalarioFinal(salarioBase * (1+complemento));
	}
	
	public String toString()
	{
		String resultado = "";
		resultado += "ANALISTA:"+super.toString();
		return resultado; 
	}

}
