package Principal;

import Principal.modelo.*;

public class Main 
{
	public static void main(String[] args) 
	{
		Empresa empresa = new Empresa("A123","Residuos humanos SL.",10);
		empresa.alta(new Analista ("456","Aila",3500,"INGENIERA DE SOFTWARE"));
		empresa.alta(new Programador ("123","Santiago",1800,"TSDAW"));
		empresa.alta(new Administrativo("789","Jaime",400,40));

		System.out.println(empresa);
	}
}
