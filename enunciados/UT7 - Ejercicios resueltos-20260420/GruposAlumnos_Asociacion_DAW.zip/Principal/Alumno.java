package Principal;

public class Alumno 
{
	private static int secuencia = 1;
	private int codigo;
	private String nombre;

	//private int codigoGrupo; // Modelo relacional
	private Grupo grupo; // Modelo OO
	
	public Alumno (String nombre)
	{
		this.codigo = secuencia;
		secuencia++;
		this.nombre = nombre;
	}
	
	public void setGrupo(Grupo g)
	{
		this.grupo = g;
	}
	
	public String toString()
	{
		String resultado ="";
		resultado += "Código: "+ this.codigo;
		resultado += " Nombre: "+ this.nombre;
		resultado += " Grupo: " + ((this.grupo==null)? "Sin grupo":grupo.getDenominacion());
		return resultado;
	}
}
