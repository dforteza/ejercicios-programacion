package Principal;

public class Grupo 
{
	private static int secuencia = 1;
	private int codigo;
	private String denominacion;
	
	private Alumno vector[];
	private int nAlumnosActual;
	
	public Grupo(String denominacion)
	{
		this.codigo = secuencia;
		secuencia++;
		this.denominacion = denominacion;
		this.vector = new Alumno[30];
		this.nAlumnosActual = 0;
	}
	
	public void addAlumno (Alumno a)
	{
		if (this.nAlumnosActual < vector.length)
		{
			this.vector[this.nAlumnosActual] = a;
			this.nAlumnosActual++;
		}
	}
	
	public String getDenominacion()
	{
		return this.denominacion;
	}
	
	public String toString()
	{
		String resultado="";
		resultado += "Código: "+this.codigo;
		resultado += " Denominacion: "+this.denominacion;
		resultado += "\n";
		for (int i=0;i<this.nAlumnosActual;i++)
			resultado += "\t"+vector[i]+"\n";
		return resultado;
	}
	
	
	
}
