package Principal;

public class EntidadTerritorial 
{
	private static int secuencia = 1; // Secuencia para numeración automática de ET
	private int codigo; // Código único de la entidad territorial
	private String nombre; // Denominación
	
	// Constructor
	public EntidadTerritorial (String nombre)
	{
		this.codigo = secuencia++;
		this.nombre = nombre;
	}
	
	// Getters
	public int getCodigo() {
		return codigo;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	// toString
	public String toString ()
	{
		String resultado = "";
		resultado += "Código: "+this.codigo;
		resultado += " Nombre: "+this.nombre;
		return resultado;
	}
}
