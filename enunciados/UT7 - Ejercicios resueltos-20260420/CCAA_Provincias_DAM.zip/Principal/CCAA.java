package Principal;

public class CCAA extends EntidadTerritorial // "es una"
{
	private String capital;
	private int poblacion;
	
	private Provincia provincias[]; //Redundante y potencialmente inconsistente
	private int nProvincias;
	
	// Constructor
	public CCAA(String nombre,String capital)
	{
		super (nombre);
		this.capital = capital;
		
		provincias = new Provincia[10];
		nProvincias = 0;
	}

	// Método para asociar una provincia a la CCAA
	public void addProvincia(Provincia p)
	{
		if (nProvincias < provincias.length)
		{
			provincias[nProvincias] = p;
			nProvincias++;
		}
	}
	// Método toString con anotación de la "sobreescritura"
	@Override
	public String toString()
	{
		String resultado="";
		resultado += "Codigo: "+getCodigo();
		resultado += " Nombre: "+getNombre();
		resultado += " Capital: "+this.capital;
		resultado +="\n";
		for (int i=0;i<nProvincias;i++)
			resultado += "\t"+provincias[i]+"\n";
		return resultado;
	}
}
