package Principal;
// Esta aplicación es un ejemplo práctico de Herencia y relaciones de asociación
// La herencia se produce entre EntidadTerritorial (clase base)
// y CCAA, Provincias (clases derivadas).
// Los conceptos explicados de la herencia son:
// - "Es un" Aspecto clave de la herencia. Referencia super y constructor super()
// - Herencia de atributos y métodos.
// - Visibilidad en caso de sobreescritura (anular - override).
// - Control de acceso: private, protected, public y "en blanco".
// Los conceptos explicados de la asociación son:
// - Modelo relacional basado en claves ajenas (FK) 
// - Modelo orientado a objeto basado en referencias a objeto (lado N).
// - Modelo orientado a objeto con redundancia basado en un vector de objetos (lado 1).

public class Main 
{
	public static void main(String[] args) 
	{
		CCAA c1;
		Provincia p1,p2;
		// Se crean los objetos usando los constructores.
		c1 = new CCAA ("Galicia","Santiago de Compostela");
		p1 = new Provincia ("Pontevedra","Pontevedrés");
		p2 = new Provincia ("Lugo","Lucense");
		
		// Se establece la asociación del lado "N"
		// 1 provincia tiene 1 CCAA		
		p1.setCCAA(c1);
		p2.setCCAA(c1);
		
		// Se establece la asociación del lado "1"
		// 1 CCAA tiene N provincias
		c1.addProvincia(p1);
		c1.addProvincia(p2);
		
		System.out.println(c1); 
	}
}
