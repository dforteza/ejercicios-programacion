package Principal;

public class Provincia extends EntidadTerritorial // "es una" 
{
	private String gentilicio;
	//private int codigoCCAA; // Modelo relacional
	private CCAA comunidadAutonoma; // Modelo OO <- recomendado
	
	// Constructor
	public Provincia (String nombre,String gentilicio)
	{
		super(nombre);
		this.gentilicio = gentilicio;
	}
	// Setters
	public void setCCAA(CCAA comunidadAutonoma)
	{
		this.comunidadAutonoma = comunidadAutonoma;
	}
	// toString
	public String toString()
	{
		String resultado ="";
		resultado += super.toString();
		resultado += " Gentilicio: "+gentilicio;
		resultado += " CCAA: "+comunidadAutonoma.getNombre();
		return resultado;
	}
}
