package Principal;

public abstract class Empleado 
{
	private String dni;
	private String nombre;
	private String apellidos;
	private int anyo;
	
	public Empleado()
	{
		
	}
	
	public Empleado(String dni, String nombre, String apellidos, int anyo) 
	{
		super();
		this.dni = dni;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.anyo = anyo;
	}

	public abstract float getSalario();
	
	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public int getAnyo() {
		return anyo;
	}

	public void setAnyo(int anyo) {
		this.anyo = anyo;
	}

	@Override
	public String toString() {
		return "Empleado [dni=" + dni + ", nombre=" + nombre + ", apellidos=" + apellidos + ", anyo=" + anyo + "]";
	}
}
