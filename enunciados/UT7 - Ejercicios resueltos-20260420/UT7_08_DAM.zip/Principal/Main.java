package Principal;

public class Main {

	public static void main(String[] args) 
	{
		Empleado vector[] = new Empleado[10];
		int nEmpleados = 0;
		
		vector[nEmpleados++] = new EmpleadoAsalariado("6546546Z","Antonio","López",2014,1125);
		vector[nEmpleados++] = new EmpleadoComision("7879879S","Sandra","Nieto",2011,169,7.10F);
		
		for (int i=0;i<nEmpleados;i++)
			System.out.println(vector[i]);
	}

}
