package Principal;

import java.time.LocalDate;

public class EmpleadoAsalariado extends Empleado 
{
	private float sueldoBase;
	private float porcentajeAdicional;

	public EmpleadoAsalariado()
	{
		super();
	}
	
	public EmpleadoAsalariado(String dni, String nombre, String apellidos, int anyo, float sueldoBase) 
	{
		super(dni, nombre, apellidos, anyo);
		this.sueldoBase = sueldoBase;
	}
	
	@Override
	public float getSalario() 
	{
		float salario;
		int nAnyos = LocalDate.now().getYear() - this.getAnyo();
		if (nAnyos>=9)
			porcentajeAdicional = 0.17F;
		else
			if (nAnyos>=4)
				porcentajeAdicional = 0.11F;
			else
				if (nAnyos>=2)
					porcentajeAdicional = 0.07F;
				else
					porcentajeAdicional = 0.0F;
		salario = sueldoBase * (1+porcentajeAdicional);
		return salario;
	}

	@Override
	public String toString() 
	{
		return super.toString()+"EmpleadoAsalariado [sueldoBase=" + sueldoBase + 
				", porcentajeAdicional=" + porcentajeAdicional + 
				" Salario: "+getSalario()+"]";
	}
}
