package Principal;

public class EmpleadoComision extends Empleado 
{
	private float salarioFijo;
	private int numeroClientesCaptados;
	private float comisionXclienteCaptado;
	
	public EmpleadoComision()
	{
		super();
		this.salarioFijo = 950;
	}
	
	public EmpleadoComision(String dni, String nombre, String apellidos, int anyo, int numeroClientesCaptados,
			float comisionXclienteCaptado) {
		super(dni, nombre, apellidos, anyo);
		this.salarioFijo = 950;
		this.numeroClientesCaptados = numeroClientesCaptados;
		this.comisionXclienteCaptado = comisionXclienteCaptado;
	}

	@Override
	public float getSalario() 
	{
		float salario;
		salario = this.numeroClientesCaptados * this.comisionXclienteCaptado;
		if (salario<salarioFijo)
			salario = salarioFijo;
		return salario;
	}

	@Override
	public String toString() {
		return super.toString()+"EmpleadoComision [salarioFijo=" + salarioFijo + 
				", numeroClientesCaptados=" + numeroClientesCaptados
				+ ", comisionXclienteCaptado=" + comisionXclienteCaptado + 
				"Salario" + getSalario()+"]";
	}

}
