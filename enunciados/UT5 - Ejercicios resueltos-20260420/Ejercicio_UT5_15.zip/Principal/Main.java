package Principal;

public class Main {

	public static void main(String[] args) 
	{
		triangulo(3);
	}
	public static void triangulo(int altura)
	{
		if (altura == 1)
			System.out.print("*");
		else
		{
			triangulo(altura-1);
			System.out.println();			
			linea (altura);
		}
	}
	public static void linea (int n)
	{
		if (n==1)
			System.out.print("*");
		else
		{
			System.out.print("*");
			linea(n-1);
		}
	}

}
