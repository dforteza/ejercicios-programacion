package Principal;

public class Main 
{
	public static void main(String[] args) 
	{
		String cadena1 = "ABCDCBA";
		String cadena2 = "ABCDEF";
		System.out.println(cadena1+" es palíndromo: "+esPalindromo(cadena1));
		System.out.println(cadena2+" es palíndromo: "+esPalindromo(cadena2));
	}
		
	public static boolean esPalindromo(String cadena)
	{
		boolean palindromo;
		
		if (cadena.length() <= 1)
			palindromo = true;
		else
		{
			if (cadena.charAt(0) == cadena.charAt(cadena.length()-1))
				palindromo = esPalindromo (cadena.substring(1, cadena.length()-1));
			else
				palindromo = false;
		}
		
		return palindromo;
	}
	
}
