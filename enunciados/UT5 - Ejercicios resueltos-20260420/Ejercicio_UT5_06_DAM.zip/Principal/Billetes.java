package Principal;

import java.time.LocalDateTime;
import java.util.Scanner;

public class Billetes 
{
	private String origen;
	private String destino;
	private LocalDateTime fSalida;
	private LocalDateTime fLlegada;
	private double precio;
	private Asientos asiento;
	
	public Billetes (Scanner sc)
	{
		boolean v,sm;
		int f;
		System.out.println("Introduzca origen:");
		this.origen = sc.nextLine();
		System.out.println("Introduzca destino:");
		this.destino = sc.nextLine();
		fSalida = LocalDateTime.now();
		fLlegada = fSalida.plusHours(2);
		this.precio = 200;
		System.out.println("¿Desea ventana?");
		v = sc.nextBoolean();
		System.out.println("¿Desea sentido de la Marcha?");
		sm = sc.nextBoolean();
		System.out.println("Fila:");
		f = sc.nextInt();
		this.asiento = new Asientos(v,sm,f);
	}
	
	public String toString()
	{
		int longitud1,longitud2,longitud;
		String resultado="";
		resultado += "Origen: "+this.origen+" ";
		resultado += "Hora de salida: "+String.format("%02d:%02d\n",fSalida.getHour(),fSalida.getMinute());
		longitud1 = resultado.length();
		resultado += "Destino: "+this.destino+" ";
		resultado += "Hora de llegada: "+String.format("%02d:%02d\n",fLlegada.getHour(),fLlegada.getMinute());
		longitud2 = resultado.length() - longitud1;
		longitud = Math.max(longitud1, longitud2);
		for (int i=0;i<longitud;i++)
			resultado += "-";
		resultado += "\n";
		resultado += "Fecha: "+String.format("%02d/%02d/%02d",fSalida.getDayOfMonth(),fSalida.getMonthValue(),fSalida.getYear());
		
		resultado += " Precio con IVA "+String.format("%.2f\n",this.precio);
		
		for (int i=0;i<longitud;i++)
			resultado += "-";
		resultado += "\n";
		
		resultado += this.asiento;
		
		return resultado;
	}
	
	
}
