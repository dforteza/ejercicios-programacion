package Principal;

public class Main 
{
	public static void main(String[] args) 
	{
		int n = 3758;
		invertirNumeroR (n);
	}

	public static void invertirNumero(int numero)
	{
		int cifra;
		
		do
		{
			cifra = numero % 10;
			numero = numero / 10;
			System.out.print(cifra);
		} while (numero != 0);
	}
	
	public static void invertirNumeroR(int numero)
	{
		int cifra;
		if (numero <10)
			System.out.print(numero);
		else
		{
			cifra = numero % 10;
			
			invertirNumeroR(numero/10);
			System.out.print(cifra);
		}
	}
}
