package Principal;

public class CuentaBancaria 
{
	private final String iban;
	private final String titular;
	private double saldo;
	private double mov1,mov2,mov3,mov4,mov5;
	private int nMovimientosActual;
	
	public CuentaBancaria(String iban,String titular)
	{
		this.iban = iban;
		this.titular = titular;
		this.saldo = 0;
		this.nMovimientosActual = 0;
	}
	
	public String getIban()
	{
		return iban;
	}
	
	public String getTitular()
	{
		return titular;
	}
	
	public double getSaldo()
	{
		return saldo;
	}
	
	public boolean ingresar (double cantidad)
	{
		boolean exito = false;
		if (cantidad > 0)
		{
			saldo = saldo + cantidad; // saldo += cantidad;
			exito = true;
			anotarMovimiento (cantidad);
		}
		return exito;
	}
	
	public boolean reintegro (double cantidad)
	{
		boolean exito = false;
		if (cantidad > 0)
		{
			if (saldo - cantidad >= -50)
			{
				saldo = saldo - cantidad;
				exito = true;
				anotarMovimiento(-cantidad);
			}
		}
		return exito;
	}
	
	private void anotarMovimiento(double cantidad)
	{
		switch (this.nMovimientosActual)
		{
		case 0: mov1 = cantidad;break;
		case 1: mov2 = cantidad;break;
		case 2: mov3 = cantidad;break;
		case 3: mov4 = cantidad;break;
		case 4: mov5 = cantidad;break;
		}
		if (this.nMovimientosActual < 5)
			this.nMovimientosActual++;
	}
	
	public String listarMovimientos()
	{
		String resultado="";
		switch (this.nMovimientosActual)
		{
		case 5: resultado += mov5 + ((mov5>0)?" Ingreso":"Reintegro")+"\n";
		case 4: resultado += mov4 + ((mov4>0)?" Ingreso":"Reintegro")+"\n";
		case 3: resultado += mov3 + ((mov3>0)?" Ingreso":"Reintegro")+"\n";
		case 2: resultado += mov2 + ((mov2>0)?" Ingreso":"Reintegro")+"\n";
		case 1: resultado += mov1 + ((mov1>0)?" Ingreso":"Reintegro")+"\n"; 
				break;
			default: resultado ="No hay movimientos\n";
		}
		
		return resultado;
	}
	
	public String toString()
	{
		String resultado="";
		resultado += "IBAN: "+iban+" Titular: "+titular+" Saldo: "+String.format("%.2f",saldo);
		return resultado;
	}
}
