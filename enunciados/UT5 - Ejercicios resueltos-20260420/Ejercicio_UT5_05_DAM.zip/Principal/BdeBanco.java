package Principal;

import java.util.InputMismatchException;
import java.util.Scanner;

public class BdeBanco 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		double cantidad;
		int opcion;
		boolean exito;
		CuentaBancaria cuenta = new CuentaBancaria("ES123456789","José Luis Pérez");
		do
		{
			opcion = menu(sc);
			switch (opcion)
			{
			case 1:
				System.out.println(cuenta);
				break;
			case 2:
				System.out.println("IBAN: "+cuenta.getIban());
				break;
			case 3:
				System.out.println("Titular: "+cuenta.getTitular());
				break;
			case 4:
				System.out.println("Saldo: "+cuenta.getSaldo());
				break;
			case 5:
				System.out.println("Introduzca cantidad a ingresar");
				cantidad = sc.nextDouble();
				exito = cuenta.ingresar(cantidad);
				if (!exito)
					System.out.println("La operación no ha podido realizarse (Cantidad negativa)");
				else
					System.out.println("Operación realizada");
				if (cantidad > 3000)
					System.out.println("AVISO: Notificar a Hacienda");
				break;
			case 6: 
				System.out.println("Introduzca cantidad a reintegrar");
				cantidad = sc.nextDouble();
				exito = cuenta.reintegro(cantidad);
				if (!exito)
				{
					System.out.print("La operación no ha podido realizarse.");
					if (cantidad<0)
						System.out.println("(Cantidad negativa)");
					else
						System.out.println("(Saldo inferior a -50)");
				}
				else
					System.out.println("Operación realizada");

				if (cantidad > 3000)
					System.out.println("AVISO: Notificar a Hacienda");
				break;
			case 7:
				System.out.println("Movimientos");
				System.out.println(cuenta.listarMovimientos());
				break;
			}
		} while (opcion!=8);
		sc.close();
	}
	
	public static int menu(Scanner sc)
	{
		int opcion;
		do 
		{
			System.out.println("1 - Datos de la cuenta");
			System.out.println("2 - IBAN");
			System.out.println("3 - Titular");
			System.out.println("4 - Saldo");
			System.out.println("5 - Ingresar");
			System.out.println("6 - Retirar");
			System.out.println("7 - Movimientos");
			System.out.println("8 - Salir");
			System.out.println("Opcion:");
			try
			{
				opcion = sc.nextInt();
			}
			catch (InputMismatchException e)
			{
				sc.nextLine();
				opcion = 0;
			}
			if (opcion<1 || opcion>8)
				System.out.println("Opción incorrecta");
		} while (opcion<1 || opcion>8);
		return opcion;
	}
}
