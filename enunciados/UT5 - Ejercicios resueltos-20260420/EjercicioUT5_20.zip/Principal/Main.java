package Principal;

enum Tipo {CRECIENTE,DECRECIENTE,VARIANTE}

public class Main 
{
	public static void main(String[] args) 
	{
		int n=123;
		Tipo resultado;
		
		resultado = getTipo (n);
		System.out.println(n +" es "+resultado);
	}
	
	public static Tipo getTipo(int n)
	{
		Tipo resultado;
		resultado = queTipotiene(n,'>');
		if (resultado == Tipo.VARIANTE)
			resultado = queTipotiene(n,'<');
		return resultado;
	}
	
	private static Tipo queTipotiene(int n,char operador)
	{
		Tipo resultado;
		int digito;
		
		if (n<10)
			resultado = (operador=='>')?Tipo.DECRECIENTE:Tipo.CRECIENTE;
		else
		{
			digito = n%10;
			n= n/10;
			if ((digito >= n%10 && operador== '<')||
			   (digito <= n%10 && operador == '>'))
				resultado = queTipotiene(n,operador);
			else
				resultado = Tipo.VARIANTE;
		}
		return resultado;
	}
}
