package Principal;

import java.time.LocalDateTime;
import java.util.Scanner;

public class Billetes 
{
	private String origen;
	private String destino;
	private LocalDateTime fSalida;
	private LocalDateTime fLlegada;
	private double precio;
	private Asientos asiento; // Se trata de una composición
	
	public Billetes(Scanner sc)
	{
		boolean ventana,sentidoMarcha;
		int fila;
		System.out.println("Introduzca Origen");
		origen = sc.nextLine();
		System.out.println("Introduzca Destino");
		destino = sc.nextLine();
		fSalida = LocalDateTime.now();
		fLlegada = fSalida.plusHours(2);
		System.out.println("Desea ventana");
		ventana = sc.nextBoolean();
		System.out.println("Desea sentido de la marcha");
		sentidoMarcha = sc.nextBoolean();
		System.out.println("Seleccione fila");
		fila = sc.nextInt();
		sc.nextLine(); // Limpiar buffer de teclado
		asiento = new Asientos(ventana,sentidoMarcha,fila);
		calcularPrecio ();
	}
	
	private void calcularPrecio ()
	{
		precio = 200; // No hay datos en el enunciado
	}
	
	public String toString()
	{
		String resultado ="";
		int longitudL1,longitudL2,longitud;
		
		resultado += "Origen: "+origen;
		resultado += String.format(" Hora de salida: %02d:%02d\n",fSalida.getHour(),fSalida.getMinute());
		longitudL1 = resultado.length();
		resultado += "Destino: "+destino;
		resultado += String.format(" Hora de llegada: %02d:%02d\n",fLlegada.getHour(),fLlegada.getMinute());
		
		longitudL2 = resultado.length() - longitudL1;
		longitud = Math.max(longitudL1, longitudL2);
		for (int i=0;i<longitud;i++)
			resultado += "-";
		resultado += "\n";

		resultado += String.format("Fecha: %02d/%02d/%02d",fSalida.getDayOfMonth(),fSalida.getMonthValue(),fSalida.getYear());
		resultado += String.format("Precio con IVA %.2f\n",precio);
		longitud = resultado.length()-longitudL1-longitudL2-longitud;
		for (int i=0;i<longitud;i++)
			resultado += "-";
		resultado += "\n";
		resultado += asiento;
		
		return resultado;
	}
	
}
