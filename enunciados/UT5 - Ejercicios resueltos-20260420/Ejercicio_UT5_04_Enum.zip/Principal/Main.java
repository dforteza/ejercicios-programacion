package Principal;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int opcion;
		String nombreZona;
		int n;
		
		do 
		{
			opcion = menu(sc);
			switch (opcion)
			{
			case 1:
				for (Zona z:Zona.values())
					System.out.println(z+" "+z.getEntradasDisponibles());
				break;
			case 2:
				System.out.println("Indica la zona ");
				nombreZona = sc.nextLine().toUpperCase();

				try 
				{
					System.out.println("En la zona "+nombreZona+" quedan "+Zona.valueOf(nombreZona).getEntradasDisponibles());
					System.out.println("¿Cuántas entradas deseas?");
					n = sc.nextInt();
					if (Zona.valueOf(nombreZona).comprar(n))
						System.out.println("Entradas vendidas");
					else
						System.out.println("No hay entradas suficientes");
				}
				catch (IllegalArgumentException  e )
				{
					System.out.println("Esa zona no existe");
				}
				catch (InputMismatchException e)
				{
					System.out.println("No ha introducido un número válido");
					sc.nextLine();
				}
				break;
			}
		} while (opcion!=3);
		sc.close();
	}

	public static int menu(Scanner sc)
	{
		int opcion;
		do
		{
			System.out.println("1 - Mostrar número de entradas");
			System.out.println("2 - Vender entradas");
			System.out.println("3 - Salir");
			System.out.println("Opción:");
			try 
			{
			opcion = sc.nextInt();
			sc.nextLine(); // Limpieza del buffer de teclado
			}
			catch (InputMismatchException e)
			{
				opcion = 0;
				sc.nextLine();
			}
			if (opcion<1 || opcion>3)
				System.out.println("Opción incorrecta");
		} while (opcion<1 || opcion>3);
		return opcion;
	}
}
