package Principal;

public enum Zona 
{
	PRINCIPAL(1000),VENTA(200),VIP(25),REVIP (2);
	private int entradasDisponibles;
	
	private Zona (int entradasDisponibles)
	{
		this.entradasDisponibles = entradasDisponibles;
	}
	
	public int getEntradasDisponibles()
	{
		return this.entradasDisponibles;
	}
	public boolean comprar (int n)
	{
		boolean exito = false;
		if (n<=this.entradasDisponibles)
		{
			this.entradasDisponibles -= n;
			exito = true;
		}
		return exito;
	}
}
