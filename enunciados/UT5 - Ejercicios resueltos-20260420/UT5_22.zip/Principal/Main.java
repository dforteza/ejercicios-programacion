package Principal;
/* 
 * Genere un programa recursivo que indique si una cadena posee paréntesis
balanceados.
 */
public class Main 
{
	public static void main(String[] args) 
	{
		String cadena ="(34(2)34)";
		boolean exito;
		exito = parentesisBalanceados(cadena);
		if (exito==true)
			System.out.println("Los paréntesis están balanceados");
		else
			System.out.println("Los paréntesis no están balanceados");

	}
	public static boolean parentesisBalanceados(String cadena)
	{
		boolean exito=false;
		int total;
		total = balanceo(cadena,0);
		if (total == 0)
			exito = true;
		return exito;
	}

	public static int balanceo (String cadena,int contador)
	{
		if (cadena.length() == 0)
			return contador;
		else
		{
			if (cadena.charAt(0)=='(')
				contador++;
			else
				if (cadena.charAt(0)==')')
					contador--;
			if (contador<0)
				return -1;
			else
				return balanceo (cadena.substring(1),contador);
		}
	}
}
