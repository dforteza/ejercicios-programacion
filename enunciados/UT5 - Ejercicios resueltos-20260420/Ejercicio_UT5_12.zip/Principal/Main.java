package Principal;

public class Main 
{
	public static void main(String[] args) 
	{
		int numero = 2;
		int exponente = 3;
		int resultado;
		
		resultado = potencia(numero,exponente);
		
		System.out.println("El resultado vale "+resultado);
	}

	public static int potencia(int base,int exponente)
	{
		int resultado = 1;
		for (int i=1;i<=exponente;i++)
			resultado = resultado * base;
		return resultado;
	}
	
	public static int potenciaR(int base,int exponente)
	{
		int resultado;
		if (exponente == 1)   // exponente == 0
			resultado = base; // resultado = 1;
		else
			resultado = base * potenciaR(base,exponente-1);
		return resultado;
	}
}
