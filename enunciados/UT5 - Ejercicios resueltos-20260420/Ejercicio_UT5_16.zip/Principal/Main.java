package Principal;

public class Main 
{
	public static void main(String[] args) 
	{
		String cadena1 = "aBCDEF";
		String cadena2 = "ZDSA";
		String cadena3 = "H";
		String cadena4 = null;
		
		System.out.println(cadena1+" está ordenada:"+cadenaOrdenada(cadena1));
		System.out.println(cadena2+" está ordenada:"+cadenaOrdenada(cadena2));
		System.out.println(cadena3+" está ordenada:"+cadenaOrdenada(cadena3));
		System.out.println(cadena4+" está ordenada:"+cadenaOrdenada(cadena4));
	}

	public static boolean cadenaOrdenada (String cadena)
	{
		boolean resultado;
		
		if (cadena != null)
			cadena = cadena.toUpperCase();
		
		resultado = estaOrdenada (cadena);
		return resultado;
	}
	
	
	
	public static boolean estaOrdenada(String cadena)
	{
		boolean ordenada;
		
		if (cadena == null || cadena.length()<=1)
			ordenada = true;
		else
		{
			if (cadena.charAt(0) <= cadena.charAt(1))
				ordenada = estaOrdenada(cadena.substring(1));
			else
				ordenada = false;
		}
		return ordenada;
	}
}
