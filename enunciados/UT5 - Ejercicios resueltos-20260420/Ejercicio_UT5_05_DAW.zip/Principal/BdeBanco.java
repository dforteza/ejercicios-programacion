package Principal;

import java.util.InputMismatchException;
import java.util.Scanner;

public class BdeBanco 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner (System.in);
		int opcion;
		CuentaBancaria cuenta = new CuentaBancaria("ES123","José Luis Izaguirre");
		double cantidad;
		do
		{
			opcion = menu(sc);
			switch (opcion)
			{
			case 1: System.out.println(cuenta);break;
			case 2: System.out.println("IBAN "+cuenta.getIBAN());break;
			case 3: System.out.println("Titular "+cuenta.getTitular());break;
			case 4: System.out.println("Saldo "+cuenta.getSaldo());break;
			case 5: 
				System.out.println("Introduzca cantidad a ingresar");
				cantidad = sc.nextDouble();
				if (cuenta.ingresar(cantidad)==false)
					System.out.println("No se ha podido hacer la operación");
				break;
			case 6:
				System.out.println("Introduzca cantidad a reitengrar");
				cantidad = sc.nextDouble();
				if (cuenta.reintegro(cantidad)==false)
					System.out.println("No se ha podido hacer la operación");
				break;

			case 7:
				System.out.println(cuenta);
				break;
			}
		} while (opcion!=8);
		sc.close();
	}
	
	public static int menu(Scanner sc)
	{
		int opcion;
		do 
		{
			System.out.println("1 - Datos de la cuenta");
			System.out.println("2 - IBAN");
			System.out.println("3 - Titular");
			System.out.println("4 - Saldo");
			System.out.println("5 - Ingresar");
			System.out.println("6 - Retirar");
			System.out.println("7 - Movimientos");
			System.out.println("8 - Salir");
			System.out.println("Opcion:");
			try
			{
				opcion = sc.nextInt();
			}
			catch (InputMismatchException e)
			{
				sc.nextLine();
				opcion = 0;
			}
			if (opcion<1 || opcion>8)
				System.out.println("Opción incorrecta");
		} while (opcion<1 || opcion>8);
		return opcion;
	}

}
