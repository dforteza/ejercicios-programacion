package Principal;

public class CuentaBancaria 
{
	private final String IBAN;
	private final String titular;
	private double saldo;
	
	private int nMovimientos;
	private double mov1,mov2,mov3,mov4,mov5;
	
	public CuentaBancaria(String IBAN, String titular) 
	{
		super();
		this.IBAN = IBAN;
		this.titular = titular;
		this.saldo = 0;
		this.nMovimientos = 0;
	}
	
	public boolean ingresar(double cantidad)
	{
		boolean exito = false;
		if (cantidad > 0)
		{
			this.saldo += cantidad;
			addMovimiento (cantidad);
			exito = true;
			if (cantidad > 3000)
				System.out.println("AVISO: Notificar a Hacienda");
		}
		return exito;
	}
	
	public void addMovimiento(double cantidad)
	{
		switch (nMovimientos)
		{
		case 0: mov1=cantidad;break;
		case 1: mov2=cantidad;break;
		case 2: mov3=cantidad;break;
		case 3: mov4=cantidad;break;
		case 4: mov5=cantidad;break;
		}
		if (nMovimientos < 5)
			nMovimientos++;
	}
	
	public boolean reintegro(double cantidad)
	{
		boolean exito = false;
		if (cantidad > 0)
		{
			if (saldo-cantidad>=-50)
			{
				saldo -= cantidad;
				addMovimiento(-cantidad);
				exito = true;
				if (saldo < 0)
					System.out.println("AVISO: Saldo negativo");
				if (cantidad > 3000)
					System.out.println("AVISO: Notificar a Hacienda");
			}
			else
				System.out.println("Saldo insuficiente");
		}				
		return exito;
	}
	
	public String getIBAN() {
		return IBAN;
	}


	public String getTitular() {
		return titular;
	}


	public double getSaldo() {
		return saldo;
	}


	public String toString()
	{
		String resultado="";
		resultado += "Cuenta: "+IBAN+" Titular: "+titular+"\n";
		resultado += "Saldo: "+saldo+"\n";
		switch (nMovimientos)
		{
		case 0: resultado += "No hay movimientos\n";break;
		case 5: resultado += "Movimiento 5: "+mov5+ ((mov5>0)?"Ingreso\n":"Reintegro\n");
		case 4: resultado += "Movimiento 4: "+mov4+ ((mov4>0)?"Ingreso\n":"Reintegro\n");
		case 3: resultado += "Movimiento 3: "+mov3+ ((mov3>0)?"Ingreso\n":"Reintegro\n");
		case 2: resultado += "Movimiento 2: "+mov2+ ((mov2>0)?"Ingreso\n":"Reintegro\n");
		case 1: resultado += "Movimiento 1: "+mov1+ ((mov1>0)?"Ingreso\n":"Reintegro\n");
		}
		return resultado;
	}
}
