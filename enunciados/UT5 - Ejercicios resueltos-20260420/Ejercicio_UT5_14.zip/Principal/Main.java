package Principal;

public class Main 
{
	public static void main(String[] args) 
	{
		rectangulo (3,4);
	}

	public static void rectangulo (int altura,int anchura)
	{
		if (altura == 1)
			linea(anchura);
		else
		{
			linea(anchura);
			System.out.println();
			rectangulo (altura-1,anchura);
		}
	}
	
	public static void linea (int n)
	{
		if (n==1)
			System.out.print("*");
		else
		{	
			System.out.print("*");
			linea(n-1);
		}
	}
}
