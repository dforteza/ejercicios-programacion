package Principal;

public class Main 
{
	public static void main(String[] args) 
	{
		int nFilas = 5;
		int nColumnas = 15;
		int marco[][] = new int[nFilas][nColumnas];
		
		// Calcular los datos de la matriz
		for (int fila=0;fila<nFilas;fila++)
			for (int columna=0;columna<nColumnas;columna++)
				if (fila==0 || columna==0 || fila==nFilas-1 || columna==nColumnas-1)
					marco[fila][columna] = 1;
				else
					marco[fila][columna] = 0;

		// Imprimir
		for (int fila=0;fila<nFilas;fila++)
		{
			for (int columna=0;columna<nColumnas;columna++)
				System.out.print(marco[fila][columna]);
			System.out.println();
		}
	}
}
