package Principal;

public class Laberinto 
{
	private char laberinto[][]= {
			"##########".toCharArray(),
			"# # #    #".toCharArray(),
			"# # #  # #".toCharArray(),
			"# # #  # #".toCharArray(),
			"#   # #  #".toCharArray(),
			"# # #   ##".toCharArray(),
			"#     #  #".toCharArray(),
			"##########".toCharArray()
	};
	private int filaEntrada=1; // Coordenadas de la entrada
	private int columnaEntrada=1;
	private int filaSalida=6; // Coordenadas de la salida
	private int columnaSalida=8;
	
	private int nFilas; // Filas del laberinto
	private int nColumnas; // Columnas del laberinto
	
	public Laberinto ()
	{
		nFilas = laberinto.length; // Número de filas de la matriz
		nColumnas = laberinto[0].length; // Número de columnas de la matriz
		laberinto[filaEntrada][columnaEntrada] = 'E'; // Señaliza la Entrada
		laberinto[filaSalida][columnaSalida]= 'S'; // Señaliza la Salida
	}

	// Método para iniciar la búsqueda de la salida desde la entrada
	public boolean encontrarSalida()
	{
		if (buscarCamino(filaEntrada,columnaEntrada,'*')==true)
			return true;
		else
			return false;
	}
	
	public boolean buscarCamino (int f,int c,char direccion)
	{
		// Evita salir de los límites de la matriz
		if (f<0 || f>=nFilas || c<0 || c>=nColumnas)
			return false;
		// Evita atravesar los muros
		if (laberinto[f][c]=='#')
			return false;
		// Evita volver a pasar por el mismo lugar 
		if (laberinto[f][c]=='*' ||
				laberinto[f][c]=='^'  ||
				laberinto[f][c]=='v' ||
				laberinto[f][c]=='<' ||
				laberinto[f][c]=='>' )
			return false;
		// Detecta la salida
		if (laberinto[f][c]=='S')
			return true;
		// Si llega aquí la casilla está disponible
		laberinto[f][c]=direccion;
		// Intenta encontrar el camino por alguna de las 4 direcciones
		if (	buscarCamino(f-1,c,'^') ||
				buscarCamino(f+1,c,'v') ||
				buscarCamino(f,c-1,'<') ||
				buscarCamino(f,c+1,'>') )
			return true;
		// Si llega aquí no ha encontrado la salida
		laberinto[f][c]=' ';
		return false;
	}

	public String toString()
	{
		String resultado="";
		for (int f=0;f<nFilas;f++)
		{
			for (int c=0;c<nColumnas;c++)
				resultado += laberinto[f][c];
			resultado += '\n';
		}
		return resultado;
	}
}







