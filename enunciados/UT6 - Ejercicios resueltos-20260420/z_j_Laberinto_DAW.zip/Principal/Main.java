package Principal;

public class Main {

	public static void main(String[] args) 
	{
		Laberinto laberinto1 = new Laberinto();
		
		System.out.println(laberinto1);
		laberinto1.encontrarSalida();
		System.out.println(laberinto1);
	}

}
