package Principal;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int opcion;
		boolean resultado;
		Empleado empleado;
		
		// Creamos el repositorio de empleados con capacidad para cuatro
		RepositorioEmpleados repositorio = new RepositorioEmpleados(4);
		do
		{
			opcion = menu(sc);
			switch (opcion)
			{
			case 1: // Alta de empleado 
				resultado = repositorio.alta(sc);
				if (resultado==true)
					System.out.println("Empleado dado de alta");
				else
					System.out.println("El empleado no ha podido ser dado de alta (Repositorio lleno)");
				break;
			case 2:// Baja de empleado por DNI
				resultado = repositorio.baja(sc);
				if (resultado == true) // if (resultado)
					System.out.println("El empleado ha sido dado de baja");
				else
					System.out.println("El empleado no ha sido localizado");
				break;
			case 3:// Consulta de empleado por DNI
				empleado = repositorio.consultarXdni(sc);
				if (empleado == null)
					System.out.println("El empleado no existe");
				else
					System.out.println(empleado);
				break;
			case 4:// Modificación de empleado por DNI
				resultado = repositorio.modificarXdni(sc);
				if (resultado == true)
					System.out.println("Modificación realizada");
				else
					System.out.println("El empleado no existe");
				break;
			case 5:// Listado de empleados
				repositorio.listado();
				break;
			default:
					System.out.println("Opción no disponible");
			}
			
		} while (opcion!=6);
		sc.close();
	}
	
	// Menú de opciones
	public static int menu(Scanner sc)
	{
		int opcion;
		do
		{
			System.out.println("MENÚ PRINCIPAL");
			System.out.println("==============");
			System.out.println("1 - Alta de empleado");
			System.out.println("2 - Baja de empleado");
			System.out.println("3 - Consultar empleado por DNI");
			System.out.println("4 - Modificar empleado");
			System.out.println("5 - Listar empleados");
			System.out.println("6 - Salir");
			System.out.println("Opción: ");
			try
			{
				opcion = sc.nextInt();
				sc.nextLine();
			}catch (InputMismatchException e)
			{
				sc.nextLine(); // Limpieza del buffer de teclado
				opcion = 0;
			}
			if (opcion<1 || opcion>6)
				System.out.println("Opción incorrecta");
		} while (opcion<1 || opcion>6);
		return opcion;
	}
}
