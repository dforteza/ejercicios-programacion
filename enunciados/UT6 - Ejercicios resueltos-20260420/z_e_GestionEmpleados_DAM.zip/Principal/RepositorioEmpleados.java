package Principal;

import java.util.Scanner;
// Esta clase constituye el respositorio de empleados
// Está basada en un vector de tipo Empleado
public class RepositorioEmpleados 
{
	private Empleado empleados[]; // Vector de tipo Empleado
	private int nEmpleados; // Número actual de empleados en el vector
	
	public RepositorioEmpleados(int n)
	{
		empleados = new Empleado[n]; // Reserva de memoria para nEmpleados
		this.nEmpleados = 0;
	}
	
	// Métodos para el alta
	public boolean alta (Empleado empleado)
	{
		boolean exito = false;
		if (nEmpleados<empleados.length)
		{
			empleados[nEmpleados] = empleado;
			nEmpleados++;
			exito = true;
		}
		return exito;
	}
		
	/**
	 * Permite dar de alta un empleado en el repositorio,
	 * @param sc Representa un objeto Scanner
	 * @return  true si logra dar de alta, false en caso contrario
	 */
	public boolean alta (Scanner sc)
	{
		boolean exito = false;
		if (nEmpleados<empleados.length)
			exito = alta(new Empleado(sc));
		return exito;
	}
	
	// Baja de empleado por DNI
	public boolean baja (String dni)
	{
		boolean exito=false;
		for (int i=0;i<nEmpleados;i++)
			if (dni.equals(empleados[i].getDni())) // if (empleados[i].getDni().equals(dni))
			{
				for (int j=i;j<nEmpleados-1;j++)
					empleados[j] = empleados[j+1];
				nEmpleados--;
				exito = true;
				break; // i--; Si se desea borrar a todos los que tengan ese dni 
			}
		return exito;
	}
	
	public boolean baja(Scanner sc)
	{
		boolean exito=false;
		String dni;
		
		System.out.println("Introduzca el dni a eliminar");
		dni = sc.nextLine();
		
		exito = baja(dni);
		return exito;
	}
	
	// Consulta de datos de un empleado por DNI
	public Empleado consultarXdni(String dni)
	{
		Empleado empleado = null;
		
		for (int i=0;i<nEmpleados;i++)
			if (dni.equals(empleados[i].getDni()))
			{
				empleado = empleados[i];
				break;
			}
		return empleado;
	}
	
	public Empleado consultarXdni (Scanner sc)
	{
		Empleado empleado = null;
		String dni;
		System.out.println("Introduzca el dni del empleado a buscar");
		dni = sc.nextLine();
		empleado = consultarXdni(dni);
		return empleado;
	}
	
	// Modificación de datos de un empleado por DNI
	public boolean modificarXdni(String dni,Scanner sc)
	{
		boolean exito = false;
		for (int i=0;i<nEmpleados;i++)
			if (dni.equals(empleados[i].getDni()))
			{
				empleados[i].actualizar(sc);
				exito = true;
				break; // Si se desea seguir buscando entonces i--
			}
		return exito;
	}
	
	public boolean modificarXdni(Scanner sc)
	{
		boolean exito;
		String dni;
		System.out.println("Introduzca dni a buscar");
		dni = sc.nextLine();
		exito = modificarXdni(dni,sc);
		return exito;
	}
	
	// Listado de empleados
	public void listado()
	{
		if (nEmpleados==0)
			System.out.println("No hay empleados actualmente");
		else
		{
			System.out.println("LISTADO DE EMPLEADOS");
			System.out.println("====================");
			for (int i=0;i<nEmpleados;i++)
				System.out.println(empleados[i]);
		}
	}
}
