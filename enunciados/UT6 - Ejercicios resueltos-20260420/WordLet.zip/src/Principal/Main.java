package Principal;

import java.io.IOException;
import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) throws IOException 
	{
		Scanner sc = new Scanner(System.in);
		String palabraBuscada; 
		String palabra;
		boolean exito = false;
		int contador = 0;
		int intentosMaximo = 5;
		String intento="";
		Diccionario diccionario= new Diccionario("palabras.txt");
		
		palabraBuscada = diccionario.getPalabra((int)(Math.random()*200));
		
		for (int i=0;i<palabraBuscada.length();i++)
			System.out.print("-");
		System.out.println();
		do
		{
			contador++;
			System.out.println("Introduzca una palabra:");
			palabra = sc.nextLine();
			if (palabra.equals(palabraBuscada))
				exito = true;
			else
			{
				intento = "";
				for (int i=0;i<palabra.length()&&i<palabraBuscada.length();i++)
					if (palabra.charAt(i)==palabraBuscada.charAt(i))
						intento += palabra.charAt(i);
					else
						intento += "-";
				System.out.println(intento);
			}
		} while (exito==false && contador<intentosMaximo);
		if (exito == true)
			System.out.println("Acertaste");
		else
			System.out.println("Tienes muy poco vocabulario");
		sc.close();
	}

}
