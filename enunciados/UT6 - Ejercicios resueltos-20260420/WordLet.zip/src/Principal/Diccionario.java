package Principal;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Diccionario 
{
	private String nombreFile;
	private String palabras[];
	
	public Diccionario (String nombreFile) throws IOException
	{
		this.nombreFile = nombreFile;
		abrirFichero();
	}
	
	public void abrirFichero() throws IOException
	{
		String linea; 
		int c=0;
		long numLineas = Files.lines(Paths.get(nombreFile)).count();
		palabras = new String[(int) numLineas];
		FileReader fr = new FileReader (nombreFile);
		BufferedReader br = new BufferedReader(fr);
		while ((linea = br.readLine() )!=null)
			palabras[c++] = linea;
		br.close();
		fr.close();
	}
	
	public String getPalabra (int i)
	{
		return palabras[i];
	}
}
