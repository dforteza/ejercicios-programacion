package Principal;

import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		String cadena;
		String resultado ="";
		boolean principioPalabra = true;
		System.out.println("Introduzca una frase");
		cadena = sc.nextLine();
		for (int i=0;i<cadena.length();i++)
			if (cadena.charAt(i)==' ')
				principioPalabra=true;
			else
			{
				if (principioPalabra==true)
				{
					resultado+=cadena.charAt(i);
					principioPalabra=false;
				}
			}
		System.out.println(resultado);
		sc.close();
	}

}
