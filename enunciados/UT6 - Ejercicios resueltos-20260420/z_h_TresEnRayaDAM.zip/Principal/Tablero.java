package Principal;

public class Tablero 
{
	private char tablero[][];
	private boolean hayGanador;
	public Tablero()
	{
		tablero = new char[3][3];
		inicializar();
	}
	
	public boolean getHayGanador()
	{
		return hayGanador;
	}
	
	
	private void inicializar()
	{
		for (int fila=0;fila<tablero.length;fila++)
			for (int columna=0;columna<tablero[0].length;columna++)
				tablero[fila][columna]='-';
	}
	
	
	public boolean mover(int fila,int columna,char ficha)
	{
		boolean exito = true;
		if (fila<0 || columna < 0 || fila>=3 || columna>=3 || 
				tablero[fila][columna]!='-')
			exito = false;
		else
		{
			tablero[fila][columna] = ficha;
			hayGanador = hayGanador(fila,columna,ficha);
		}
		return exito;
	}
	
	public boolean moverIA ()
	{
		for (int f=0;f<tablero.length;f++)
			for (int c=0;c<tablero[0].length;c++)
				if (tablero[f][c]=='-')
				{
					tablero[f][c]='x';
					hayGanador = hayGanador(f,c,'x');
					return true;
				}
		return false;
	}
	
	public boolean moverIARandom()
	{
		int f,c;
		do
		{
			f = (int) (Math.random()*3);
			c = (int) (Math.random()*3);
		} while (tablero[f][c]!='-');
		tablero[f][c]='x';
		hayGanador = hayGanador(f,c,'x');
		return true;
	}
	
	public boolean tableroCompleto()
	{
		for (int f=0;f<tablero.length;f++)
			for (int c=0;c<tablero[0].length;c++)
				if (tablero[f][c]=='-')
					return false;
		return true;
	}

	
	public boolean hayGanador(int fila,int columna,char ficha)
	{
		if (hayGanadorFila(fila,columna,ficha) || 
				hayGanadorColumna(fila,columna,ficha) ||
				hayGanadorD(fila,columna,ficha) ||
				hayGanadorDS(fila,columna,ficha)) 
			return true;
		else
			return false;
	}

	public boolean hayGanadorDS(int fila,int columna,char ficha)
	{
		int contador = 0;
		for (int i=0;i<tablero.length;i++) // for (int i=0,j=2;i<tablero.length;i++,j--)
			if (tablero[i][3-1-i]==ficha)
				contador++;
		if (contador==3)
			return true;
		else
			return false;
	}
	
	public boolean hayGanadorD(int fila,int columan,char ficha)
	{
		int contador=0;
		for (int i=0;i<tablero.length;i++)
			if (tablero[i][i]==ficha)
				contador++;
		if (contador==3)
			return true;
		else
			return false;
	}

	
	public boolean hayGanadorColumna (int fila,int columna,char ficha)
	{
		int contador=0;
		for (int f=0;f<tablero.length;f++)
			if (tablero [f][columna]==ficha)
				contador++;
		if (contador==3)
			return true;
		else
			return false;
	}
	public boolean hayGanadorFila(int fila,int columna,char ficha)
	{
		int contador=0;
		for (int c=0;c<tablero[0].length;c++)
			if (tablero[fila][c]==ficha)
				contador++;
		if (contador == 3) // Número mágico
			return true;
		else
			return false;
	}
	
	
	public String toString()
	{
		String resultado="";
		resultado += "TABLERO\n";
		resultado += "=======\n";
		for (int f=0;f<tablero.length;f++)
		{
			for (int c=0;c<tablero[0].length;c++)
				resultado += String.format(" %c", tablero[f][c]);
			resultado += "\n";
		}
		return resultado;
	}
	
}
