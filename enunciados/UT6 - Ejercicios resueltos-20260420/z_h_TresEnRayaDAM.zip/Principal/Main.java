package Principal;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		Tablero tablero = new Tablero();
		int fila,columna;
		boolean exito;
		boolean turnoIA = false;

		do
		{
			System.out.println(tablero);
			if (turnoIA==false) // Turno del jugador
			{
				do
				{
					System.out.println("Introduzca la fila y la columna (0-2)");
					fila = sc.nextInt();
					columna = sc.nextInt();
					exito = tablero.mover(fila, columna, 'o');
					if (exito==false)
						System.out.println("La ficha no ha podido colocarse");
				} while (exito==false);
				
			}
			else	// Turno del ordenador
			{
				tablero.moverIARandom();
			}
			turnoIA =!turnoIA;
		} while (!tablero.getHayGanador() && tablero.tableroCompleto()==false);
		System.out.println(tablero);
		if (tablero.getHayGanador())
			System.out.println("Ha ganado "+(turnoIA?" jugador":" ordenador"));
		sc.close();
	}

}
