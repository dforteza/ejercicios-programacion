package Principal;

import java.time.LocalDate;
import java.util.Scanner;

public class Libro 
{
	private String titulo;
	private int edicion;
	private String autores;
	private String isbn;
	private String editorial;
	private String direccion;
	private LocalDate fecha;
	private int paginas;
	private int ejemplares;
	
	public Libro(String titulo, int edicion, String autores, String isbn, String editorial, String direccion,
			LocalDate fecha, int paginas,int ejemplares) {
		super();
		this.titulo = titulo;
		this.edicion = edicion;
		this.autores = autores;
		this.isbn = isbn;
		this.editorial = editorial;
		this.direccion = direccion;
		this.fecha = fecha;
		this.paginas = paginas;
		this.ejemplares = ejemplares;
	}

	
	public Libro (Scanner sc)
	{
		System.out.println("Título");
		titulo = sc.nextLine();
		System.out.println("Edicion");
		this.edicion =Integer.parseInt (sc.nextLine());
		System.out.println("Autor:");
		this.autores = sc.nextLine();
		System.out.println("ISBN");
		this.isbn = sc.nextLine();
		System.out.println("Editorial");
		this.editorial = sc.nextLine();
		System.out.println("Dirección");
		this.direccion = sc.nextLine();
		
		System.out.println("Fecha (dd/mm/aaaa)");
		String tokens[] = sc.nextLine().split("/");
		this.fecha = LocalDate.of(
				Integer.parseInt (tokens[2]),
				Integer.parseInt (tokens[1]),
				Integer.parseInt (tokens[0]));
		
		System.out.println("Número de páginas");
		this.paginas = Integer.parseInt(sc.nextLine());
		System.out.println("Ejemplares:");
		this.ejemplares = Integer.parseInt(sc.nextLine());
	}
	
	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public int getEdicion() {
		return edicion;
	}

	public void setEdicion(int edicion) {
		this.edicion = edicion;
	}

	public String getAutores() {
		return autores;
	}

	public void setAutores(String autores) {
		this.autores = autores;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getEditorial() {
		return editorial;
	}

	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public int getPaginas() {
		return paginas;
	}

	public void setPaginas(int paginas) {
		this.paginas = paginas;
	}
	
	
	
	public int getEjemplares() {
		return ejemplares;
	}


	public void setEjemplares(int ejemplares) {
		this.ejemplares = ejemplares;
	}


	public void modificarCampos(Scanner sc)
	{
		String cadena;
		System.out.println("ISBN: "+isbn);
		System.out.println("Titulo: "+titulo);
		cadena = sc.nextLine();
		if (cadena.length()>0)
			this.titulo = cadena;
		
		System.out.println("Edicion: "+edicion);
		cadena = sc.nextLine();
		if (cadena.length()>0)
			this.edicion = Integer.parseInt(cadena);

		System.out.println("Autor: "+autores);
		cadena = sc.nextLine();
		if (cadena.length()>0)
			this.autores = cadena;
		
		System.out.println("Editorial: "+editorial);
		cadena = sc.nextLine();
		if (cadena.length()>0)
			this.editorial = cadena;
		
		System.out.println("Dirección: "+direccion);
		cadena = sc.nextLine();
		if (cadena.length()>0)
			this.direccion= cadena;
		
		System.out.println("Fecha: "+fecha);
		cadena = sc.nextLine();
		if (cadena.length()>0)
		{			
			String tokens[] = cadena.split("/");
			this.fecha = LocalDate.of(
					Integer.parseInt (tokens[2]),
					Integer.parseInt (tokens[1]),
					Integer.parseInt (tokens[0]));
		}
		
		System.out.println("Número de páginas:"+paginas);
		cadena = sc.nextLine();
		if (cadena.length()>0)
			this.paginas= Integer.parseInt(cadena);
		
		System.out.println("Ejemplares:"+ejemplares);
		cadena = sc.nextLine();
		if (cadena.length()>0)
			this.ejemplares= Integer.parseInt(cadena);
	}
	
	@Override
	public String toString() {
		return "Libro [titulo=" + titulo + ", edicion=" + edicion + ", autores=" + autores + ", isbn=" + isbn
				+ ", editorial=" + editorial + ", direccion=" + direccion + ", fecha=" + fecha + ", paginas=" + paginas
				+ "Ejemplare "+ejemplares+"]";
	}
}
