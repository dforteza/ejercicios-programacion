package Principal;

import java.util.Scanner;

public class Catalogo 
{
	private Libro biblioteca[];
	private int nLibrosActual;
	
	public Catalogo (int n)
	{
		biblioteca = new Libro[n];
		nLibrosActual = 0;
	}
	
	public boolean alta (Libro libro)
	{
		boolean exito = false;
		if (this.nLibrosActual < biblioteca.length)
		{
			biblioteca[nLibrosActual] = libro;
			this.nLibrosActual++;
			exito = true;
		}
		return exito;
	}
	
	public boolean alta (Scanner sc)
	{
		boolean exito = false;
		if (this.nLibrosActual < biblioteca.length)
		{
			exito = alta(new Libro(sc));
		}
		return exito;
	}
	
	public boolean baja (Scanner sc)
	{
		boolean exito;
		String isbn;
		System.out.println("Introduzca el isbn");
		isbn = sc.nextLine();
		exito = baja (isbn);
		return exito;
	}
	
	public boolean baja(String isbn)
	{
		boolean exito = false;
		for (int i=0;i<this.nLibrosActual;i++)
			if (isbn.equals(biblioteca[i].getIsbn()))
			{
				for (int j=i;j<this.nLibrosActual-1;j++)
					biblioteca[j] = biblioteca[j+1];
				this.nLibrosActual--;
				exito = true;
				break; //i--; 
			}
		return exito;
	}
	
	public int bajaXAutor(String autor)
	{
		int totalBorrados = 0;
		for (int i=0;i<this.nLibrosActual;i++)
			if (autor.equals(biblioteca[i].getAutores()))
			{
				for (int j=i;j<this.nLibrosActual-1;j++)
					biblioteca[j] = biblioteca[j+1];
				this.nLibrosActual--;
				totalBorrados++;
				i--; 
			}
		return totalBorrados;
	}
	
	public Libro buscarXisbn(String isbn)
	{
		Libro libro = null;
		for (int i=0;i<this.nLibrosActual;i++)
			if (isbn.equals(biblioteca [i].getIsbn()))
			{
				libro = biblioteca[i];
				break;
			}
		
		return libro;
	}
	
	public Libro modificarXisbn(String isbn,Scanner sc)
	{
		Libro libro = null;
		for (int i=0;i<this.nLibrosActual;i++)
			if (isbn.equals(biblioteca [i].getIsbn()))
			{
				biblioteca[i].modificarCampos(sc);
				libro = biblioteca[i];
				break;
			}
		
		return libro;
	}
	
	public String listadoOrdenado()
	{
		Libro seleccion[] = new Libro[this.biblioteca.length];
		int contador=0;
		Libro aux;
		String resultado="";
		
		for (int i=0;i<this.nLibrosActual;i++)
			if (biblioteca[i].getEjemplares()<=2)
			{
				seleccion[contador] = biblioteca[i];
				contador++;
			}
		for (int i=0;i<contador-1;i++)
			for (int j=i+1;j<contador;j++)
				
				if (seleccion[i].getTitulo().compareTo(seleccion[j].getTitulo())>0)
				{
					aux = seleccion[i];
					seleccion[i] = seleccion[j];
					seleccion[j]=aux;
				}
		
		for (int i=0;i<contador;i++)
			resultado += seleccion[i]+"\n";
		return resultado;
	}
	
	
	public String toString()
	{
		String resultado ="";
		if (this.nLibrosActual==0)
			resultado += "NO HAY LIBROS";
		else
		{
			for (int i=0;i<this.nLibrosActual;i++)
				resultado += biblioteca[i]+"\n";
		}
		return resultado;
	}
	
}






