package Principal;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		Catalogo miCatalogo = new Catalogo(100);
		int opcion;
		boolean exito;
		String isbn;
		Libro libro;
		do
		{
			opcion = menu(sc);
			switch (opcion)
			{
			case 1:
				exito = miCatalogo.alta(sc);
				if (exito)
					System.out.println("Alta correcta");
				else
					System.out.println("Catálogo lleno");
				break;
			case 2: 
				exito = miCatalogo.baja(sc);
				if (exito)
					System.out.println("Baja correcta");
				else
					System.out.println("El libro no existe");
				break;
			case 3: 
				System.out.println("Qué libro modificar: isbn");
				isbn = sc.nextLine();
				if (miCatalogo.modificarXisbn(isbn, sc)==null)
					System.out.println("El libro no existe");
				break;
			case 4: 
				System.out.println("Qué libro modificar: isbn");
				isbn = sc.nextLine();
				libro = miCatalogo.buscarXisbn(isbn);
				if (libro==null)
					System.out.println("El libro no existe");
				else
					System.out.println(libro);
				break;
				
			case 5:
				System.out.println(miCatalogo);
				break;
			case 6:
				System.out.println(miCatalogo.listadoOrdenado());
				break;
			}
			
		} while (opcion!=7);
		sc.close();
	}
	
	public static int menu(Scanner sc)
	{
		int op;
		do
		{
			System.out.println("1 - Alta de libro");
			System.out.println("2 - Baja de libro");
			System.out.println("3 - Modificar libro");
			System.out.println("4 - Buscar libro");
			System.out.println("5 - Listado de libros");
			System.out.println("6 - Listado ordenado libros 2 o menos ejemplares");
			System.out.println("7 - Salir");
			System.out.println("Opcion:");
			try
			{
				op = sc.nextInt();
			} catch (InputMismatchException e)
			{
				op = 0;
			}
			sc.nextLine(); // Limpiar el buffer
			if (op<1 || op>7)
				System.out.println("Opción incorrecta");
		} while ((op<1 || op>7));
		return op;
	}
}
