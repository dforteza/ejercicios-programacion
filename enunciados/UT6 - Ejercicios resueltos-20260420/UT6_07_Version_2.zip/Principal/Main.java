package Principal;

import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		String cadena;
		String resultado = "";
		int estado = 0;
		char letra;
		System.out.println("Introduzca una frase");
		cadena = sc.nextLine();
		for (int i=0;i<cadena.length();i++)
		{
			letra = cadena.charAt(i);
			switch (estado)
			{
			case 0:
				if (letra!=' ')
				{
					resultado += letra;
					estado = 1;
				}
				break;
			case 1:
				if (letra==' ')
					estado = 0;
				break;
			}
		}
		System.out.println(resultado);
		sc.close();
	}

}
