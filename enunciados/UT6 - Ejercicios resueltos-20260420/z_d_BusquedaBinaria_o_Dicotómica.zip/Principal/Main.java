package Principal;

import java.util.Arrays;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner (System.in);
		
		int numeros[] = new int[20];
		int limiteInferior,limiteSuperior;
		int posicionIntermedia = 0;
		boolean encontrado = false;
		int numeroBuscado;
		
		for (int i=0;i<numeros.length;i++)
			numeros[i] = (int) (Math.random()*100);
		
		Arrays.sort(numeros);
		
		for (int i=0;i<numeros.length;i++)
			System.out.print(numeros[i]+" ");
		System.out.println();
		System.out.println("Indique el número que desea buscar");
		numeroBuscado = sc.nextInt();
		
		limiteInferior = 0;
		limiteSuperior = numeros.length-1;
		while (limiteInferior <= limiteSuperior)
		{
			posicionIntermedia = (limiteInferior+limiteSuperior)/2;
			if (numeroBuscado == numeros[posicionIntermedia])
			{
				encontrado = true;
				break;
			}
			else
				if (numeroBuscado > numeros[posicionIntermedia])
					limiteInferior = posicionIntermedia+1;
				else
					limiteSuperior = posicionIntermedia-1;
		}
		if (encontrado == true)
			System.out.println("El elemento existe "+posicionIntermedia);
		else
			System.out.println("El elemento no existe");
			   
		sc.close();
	}

}
