package Principal;

public class Main 
{
	public static void main(String[] args) 
	{
		Laberinto laberinto = new Laberinto();
		System.out.println(laberinto);
		
		if (laberinto.encontrarSalida())
		{
			System.out.println("Salida encontrada");
			System.out.println(laberinto);
		}
		else
			System.out.println("No he logrado encontrar la salida");
	}
}
