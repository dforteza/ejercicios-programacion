package Principal;

public class Laberinto 
{
	private int filas;
	private int columnas;
	
	// Coordenadas de la entrada
	private int entrada[] = {1,1};
	//private int filaEntrada = 1;
	//private int columnaEntrada = 1;
	
	// Coordenadas de la salida
	private int salida[] = {7,1};
	//private int filaSalida = 7;
	//private int columnaSalida = 1;
	
	// Laberinto
	private char [][] laberinto = {
			"##########".toCharArray(),
			"#   #    #".toCharArray(),
			"# # # ## #".toCharArray(),
			"# #    # #".toCharArray(),
			"# #### # #".toCharArray(),
			"#      # #".toCharArray(),
			"###### # #".toCharArray(),
			"#        #".toCharArray(),
			"##########".toCharArray()};
	public Laberinto ()
	{
		this.filas = laberinto.length;
		this.columnas = laberinto[0].length;
		// Ubicar entrada
		laberinto[entrada[0]][entrada[1]]='E';
		//laberinto[filaEntrada][columnaEntrada]='E';
		
		// Ubicar salida
		laberinto[salida[0]][salida[1]] ='S';
		// laberinto[filaSalida][columnaSalida] = 'S';
	}
	
	public boolean encontrarSalida()
	{
		if (buscarCamino(entrada[0],entrada[1]))
			return true;
		else
			return false;
	}
	
	public boolean buscarCamino(int f,int c)
	{
		// Para evitar salirse de los límites 
		if (f<0 || f>=filas || c<0 || c>=columnas)
			return false;
		// Para evitar cruzar paredes
		if (laberinto[f][c]=='#')
			return false;
		// Para evitar pasar dos veces por el mismo sitio
		if (laberinto[f][c]=='*')
			return false;
		// Para detectar la salida
		if (laberinto[f][c]=='S')
			return true;
		// Marcar la casilla como visitada
		laberinto[f][c]='*';
		
		// Moverse en las cuatro direcciones
		if (buscarCamino (f-1,c) || // Arriba
				buscarCamino(f+1,c)|| // Abajo
				buscarCamino(f,c-1)|| // Izquierda
				buscarCamino(f,c+1))// Derecha
			return true;
		laberinto[f][c]=' ';
		return false;
	}
	
	
	public String toString()
	{
		String resultado="";
		for (int f=0;f<filas;f++)
		{
			for (int c=0;c<columnas;c++)
				resultado += laberinto[f][c];
			resultado +="\n";
		}
		return resultado;
	}
}
