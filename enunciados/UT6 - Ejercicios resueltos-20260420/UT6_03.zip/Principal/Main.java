package Principal;

import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int numeros[] = new int[5]; // Declaro y reservo.
		int n,nElementos=0;
		int suma = 0;
		int producto = 1;
		// Entrada de datos
		System.out.println("Introduzca enteros (negativo=FIN)");
		n = sc.nextInt();
		while (n>=0 && nElementos<numeros.length)
		{
			numeros[nElementos] = n;
			nElementos++;
			System.out.println("Introduzca enteros (negativo=FIN)");
			n = sc.nextInt();
		}
		
		// Calcular suma y producto
		
		for (int i=0;i<nElementos;i++)
		{
			suma = suma +numeros[i];
			producto = producto * numeros[i];
		}
		
		// Imprimir resultados
		for (int i=0;i<nElementos;i++)
			System.out.print(numeros[i]+" ");
		System.out.println("La suma vale "+suma);
		System.out.println("El producto vale "+producto);
		sc.close();
	}

}
