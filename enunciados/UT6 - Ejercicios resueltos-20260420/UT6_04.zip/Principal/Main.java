package Principal;

public class Main 
{
	public static void main(String[] args) 
	{
		int numeros[] = new int[20];
		int primos[] = new int[numeros.length];
		int nElementos = 0; // Cantidad de primos encontrados
		
		// Rellenar con los números aleatorios
		for (int i=0;i<numeros.length;i++)
			numeros[i] = (int)(Math.random()*100);
		
		// Determinar cuáles son primos
		for (int i=0;i<numeros.length;i++)
			if (esPrimo(numeros[i]) == true)
			{
				primos[nElementos] = numeros[i];
				nElementos++;
			}
		
		//Imprimir resultados
		for (int i=0;i<numeros.length;i++)
			System.out.print(numeros[i]+" ");
		System.out.println();
		
		for (int i=0;i<nElementos;i++)
			System.out.print(primos[i]+" ");
	}
	
	public static boolean esPrimo(int n)
	{
		boolean primo = (n<2)?false:true;
		
		for (int i=2;i<n;i++)
			if (n%i == 0)
			{
				primo = false;
				break;
			}
		return primo;
	}
	
	
	
	
}
