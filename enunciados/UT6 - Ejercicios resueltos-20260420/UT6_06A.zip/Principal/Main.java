package Principal;

public class Main 
{
	public static void main(String[] args) 
	{
		int numeros[] = {30,10,15,20,40};

		int invertidos[] = new int [numeros.length];
		
		for (int i=0;i<invertidos.length;i++)
			invertidos [i] = numeros[numeros.length-i-1];
		
		for (int i=0;i<numeros.length;i++)
			System.out.print(numeros[i]+" ");
		System.out.println();
		for (int i=0;i<invertidos.length;i++)
			System.out.print(invertidos[i]+" ");
	}
}
