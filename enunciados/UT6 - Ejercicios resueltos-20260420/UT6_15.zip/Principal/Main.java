package Principal;

import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner (System.in);
		double vector[]; // Vector que almacenará la suma de cada fila
		double matriz[][]; // Matriz de números
		int nFilas=4; // Número de filas
		int nColumnas = 5; // Número de columnas
		matriz = new double [nFilas][nColumnas]; // Reservar matriz
		vector = new double[nFilas]; // Reservar vector
		double suma; // Variable auxiliar acumulador de suma
		
		// Lectura de los datos
		System.out.println("Introduzca los elementos de la matriz por filas");
		for (int fila=0;fila<nFilas;fila++)
			for (int columna=0;columna<nColumnas;columna++)
				matriz[fila][columna] = sc.nextDouble();
		
		// Calcular la suma por filas
		for (int fila=0;fila<nFilas;fila++)
		{
			suma = 0;
			for (int columna=0;columna<nColumnas;columna++)
				suma = suma + matriz[fila][columna];
			vector[fila] = suma;
		}
		
		// Impresión de los resultados
		for (int fila=0;fila<nFilas;fila++)
		{
			for (int columna=0;columna<nColumnas;columna++)
				System.out.printf("%4.0f ",matriz[fila][columna]);
			System.out.printf("%6.0f \n",vector[fila]);
		}
		
		sc.close();
	}
}
