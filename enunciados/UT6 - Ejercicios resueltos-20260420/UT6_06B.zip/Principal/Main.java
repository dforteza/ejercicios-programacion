package Principal;

public class Main 
{
	public static void main(String[] args) 
	{
		int numeros[] = {30,10,15,20,40};
		int invertidos[] = new int [numeros.length];

		
		for (int i=0,p=numeros.length-1;i<numeros.length;i++,p--)
			invertidos[p] = numeros[i];
		
		// Impresión de resultados
		for (int i=0;i<numeros.length;i++)
			System.out.print(numeros[i]+" ");
		System.out.println();
		for (int i=0;i<invertidos.length;i++)
			System.out.print(invertidos[i]+" ");
	}
}
