package Principal;

import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		Tablero tablero = new Tablero(3,3,3);
		boolean exito;
		int fila,columna;
		boolean turnoIA = false;
		
		do
		{
			System.out.println(tablero);

			if (turnoIA) // Es el turno de la IA
			{
				//tablero.moverIARandom('x');
				tablero.moverIAMiniMax('x');
			}
			else // Es el turno del jugador
			{
				do
				{
					System.out.println("Indique fila y columna del movimiento:");
					fila = sc.nextInt();
					columna = sc.nextInt();
					exito = tablero.mover(fila,columna,'o');
					if (exito==false)
						System.out.println("La posición no es correcta");
				} while (exito==false);

			}
			if (tablero.getGanador()==true)
				System.out.println("Ha ganado "+((turnoIA)?" la IA":" usted."));
			turnoIA = !turnoIA; 
		} while (!tablero.getGanador() && tablero.completo()==false);
		
		if (!tablero.getGanador())
			System.out.println("Empate. El tablero está completo.");
		System.out.println(tablero);
		sc.close();
	}
}
