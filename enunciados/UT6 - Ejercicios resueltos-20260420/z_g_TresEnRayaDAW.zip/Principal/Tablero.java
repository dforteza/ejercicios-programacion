package Principal;

public class Tablero 
{
	private char tablero[][];
	private boolean ganador;
	private int n;
	private int nFilas,nColumnas;
	
	public Tablero(int nFilas,int nColumnas,int n) // n representa el número de fichas para ganar
	{
		tablero = new char[nFilas][nColumnas];
		ganador = false;
		this.n = n;
		this.nFilas = nFilas;
		this.nColumnas = nColumnas;
		inicializar();
	}
	
	public void inicializar()
	{
		for (int f=0;f<tablero.length;f++)
			for (int c=0;c<tablero[0].length;c++)
				tablero[f][c]='-';
	}
	
	public boolean getGanador()
	{
		return this.ganador;
	}
	
	
	public boolean mover(int fila,int columna,char ficha)
	{
		boolean exito=true;
		if (fila<0 || fila>=nFilas || columna<0 || columna>=nColumnas)
			exito = false;
		else
		{
			if (tablero[fila][columna] == '-')
			{
				tablero[fila][columna] = ficha;
				ganador = hayGanador(fila,columna,ficha);
			}
			else
				exito = false;
		}
		return exito;
	}
	
	public boolean completo()
	{
		for (int f=0;f<tablero.length;f++)
			for (int c=0;c<tablero[0].length;c++)
				if (tablero[f][c]=='-')
					return false;
		return true;
	}
	
	
	public boolean moverIA (char ficha)
	{
		boolean exito = false;
		for (int f=0;f<tablero.length;f++)
			for (int c=0;c<tablero[0].length;c++)
				if (tablero[f][c]=='-')
				{
					tablero[f][c]=ficha;
					exito = true;
					ganador = hayGanador(f,c,ficha);
					return exito;
				}
		return exito;
	}
	
	public boolean moverIARandom(char ficha)
	{
		int f,c;
		boolean exito;
		
		do
		{
			f = (int)(Math.random()*nFilas);
			c = (int)(Math.random()*nColumnas);
			if (tablero[f][c]=='-')
			{
				tablero[f][c] = ficha;
				ganador = hayGanador(f,c,ficha);
				exito = true;
			}
			else
				exito = false;
		} while (exito==false);
			return exito;
	}
	
	public boolean hayGanador (int fila,int columna,char ficha)
	{
		return hayGanadorH(fila,columna,ficha) || 
				hayGanadorV(fila,columna,ficha) || 
				hayGanadorD(fila,columna,ficha) ||
				hayGanadorS(fila,columna,ficha);
	}
	
	
	public boolean hayGanadorH (int fila,int columna,char ficha)
	{
		int contador;
		contador = 1;
		for (int c=columna-1;c>=0;c--)
			if (tablero[fila][c]==ficha)
				contador++;
			else
				break;
		for (int c=columna+1;c<tablero[0].length;c++)
			if (tablero[fila][c]==ficha)
				contador++;
			else
				break;
		if (contador==n)
			return true;
		else
			return false;
	}

	public boolean hayGanadorV (int fila,int columna,char ficha)
	{
		int contador;
		contador = 1;
		for (int f=fila-1;f>=0;f--)
			if (tablero[f][columna]==ficha)
				contador++;
			else
				break;
		for (int f=fila+1;f<tablero.length;f++)
			if (tablero[f][columna]==ficha)
				contador++;
			else
				break;
		if (contador==n)
			return true;
		else
			return false;
	}

	
	public boolean hayGanadorD(int fila,int columna,char ficha)
	{
		int contador = 1;
		
		// Arriba izquierda
		for (int f=fila-1,c=columna-1;f>=0&&c>=0;f--,c--)
			if (tablero[f][c]==ficha)
				contador++;
			else
				break;
		// Abajo derecha
		for (int f=fila+1,c=columna+1;f<nFilas&&c<nColumnas;f++,c++)
			if (tablero[f][c]==ficha)
				contador++;
			else
				break;
		if (contador==n)
			return true;
		else
			return false;
	}
	
	public boolean hayGanadorS(int fila,int columna,char ficha)
	{
		int contador = 1;
		
		// Abajo izquierda
		for (int f=fila+1,c=columna-1;f<nFilas&&c>=0;f++,c--)
			if (tablero[f][c]==ficha)
				contador++;
			else
				break;
		// Arriba derecha
		for (int f=fila-1,c=columna+1;f>=0&&c<nColumnas;f--,c++)
			if (tablero[f][c]==ficha)
				contador++;
			else
				break;
		if (contador==n)
			return true;
		else
			return false;
	}

	
	
	
	public String toString()
	{
		String resultado="";
		resultado += "TABLERO\n";
		resultado += "=======\n";
		for (int f=0;f<tablero.length;f++)
		{
			for (int c=0;c<tablero[0].length;c++)
				resultado += " "+tablero[f][c];
			resultado +="\n";
		}
		return resultado;
	}
	
	// --- AUXILIARES PARA MINIMAX ---

	// Evalúa el tablero desde la perspectiva de la IA (ai).
	//  +10 si gana la IA, -10 si gana el humano, 0 si no hay ganador aún.
	private int evaluar(char ai, char humano) {
	    if (hayGanadorTotal(ai))   return  10;
	    if (hayGanadorTotal(humano)) return -10;
	    return 0;
	}

	// Revisa si 'ficha' tiene n en raya en el tablero actual.
	// Reutiliza tus métodos de línea empezando desde cualquier celda que contenga esa ficha.
	private boolean hayGanadorTotal(char ficha) {
	    for (int f = 0; f < nFilas; f++) {
	        for (int c = 0; c < nColumnas; c++) {
	            if (tablero[f][c] == ficha) {
	                if (hayGanadorH(f, c, ficha) || hayGanadorV(f, c, ficha)
	                    || hayGanadorD(f, c, ficha) || hayGanadorS(f, c, ficha)) {
	                    return true;
	                }
	            }
	        }
	    }
	    return false;
	}

	// Minimax con poda alfa-beta.
	// depth: profundidad actual
	// isMax: true si es turno de la IA (maximizador), false si es turno del humano (minimizador).
	private int minimax(int depth, boolean isMax, char ai, char humano, int alpha, int beta) {
	    int score = evaluar(ai, humano);

	    // Estados terminales con "preferencia temporal": ganar antes (+) o perder más tarde (-)
	    if (score == 10)  return score - depth; // ganar rápido es mejor
	    if (score == -10) return score + depth; // perder tarde es menos malo
	    if (completo())   return 0;             // empate

	    if (isMax) {
	        int best = Integer.MIN_VALUE;

	        for (int f = 0; f < nFilas; f++) {
	            for (int c = 0; c < nColumnas; c++) {
	                if (tablero[f][c] == '-') {
	                    tablero[f][c] = ai; // probar jugada IA
	                    int val = minimax(depth + 1, false, ai, humano, alpha, beta);
	                    tablero[f][c] = '-'; // deshacer

	                    best = Math.max(best, val);
	                    alpha = Math.max(alpha, best);
	                    if (beta <= alpha) return best; // poda
	                }
	            }
	        }
	        return best;
	    } else {
	        int best = Integer.MAX_VALUE;

	        for (int f = 0; f < nFilas; f++) {
	            for (int c = 0; c < nColumnas; c++) {
	                if (tablero[f][c] == '-') {
	                    tablero[f][c] = humano; // probar jugada rival
	                    int val = minimax(depth + 1, true, ai, humano, alpha, beta);
	                    tablero[f][c] = '-'; // deshacer

	                    best = Math.min(best, val);
	                    beta = Math.min(beta, best);
	                    if (beta <= alpha) return best; // poda
	                }
	            }
	        }
	        return best;
	    }
	}

	// Encuentra el mejor movimiento para la IA (ai) contra 'humano'.
	private int[] mejorMovimiento(char ai, char humano) {
	    int bestVal = Integer.MIN_VALUE;
	    int[] mejor = null;

	    for (int f = 0; f < nFilas; f++) {
	        for (int c = 0; c < nColumnas; c++) {
	            if (tablero[f][c] == '-') {
	                tablero[f][c] = ai;
	                int moveVal = minimax(0, false, ai, humano, Integer.MIN_VALUE, Integer.MAX_VALUE);
	                tablero[f][c] = '-';

	                // Empata por: mejor puntuación, ganar antes (menor profundidad implícita),
	                // y como desempate secundario, puedes priorizar centro/corners si es 3x3 (opcional).
	                if (moveVal > bestVal) {
	                    bestVal = moveVal;
	                    mejor = new int[]{f, c};
	                }
	            }
	        }
	    }
	    return mejor; // puede ser null si no hay movimientos
	}

	// --- API PÚBLICA: Mueve la IA con Minimax ---
	public boolean moverIAMiniMax(char ficha) {
	    // Deducimos la ficha del rival. Si usas solo 'x' y 'o', esto es robusto.
	    char humano = (Character.toLowerCase(ficha) == 'x') ? 'o' : 'x';

	    int[] move = mejorMovimiento(ficha, humano);
	    if (move == null) return false; // no hay movimientos (tablero lleno)

	    int f = move[0], c = move[1];
	    tablero[f][c] = ficha;
	    ganador = hayGanador(f, c, ficha);
	    return true;
	}
	
}






