package Principal;

import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int numeros[] = {10,15,15,15,20,30,40,80};
		int n;
		boolean exito = false;
		
		int posiciones[] = new int[numeros.length];
		int nElementos = 0;
		
		
		System.out.println("Indica el número que quieres buscar");
		n = sc.nextInt();
		
		for (int i=0;i<numeros.length;i++)
		{
			if (numeros[i]>n)
				break;
			if (numeros[i] == n)
			{
				exito = true;
				posiciones[nElementos] = i;
				nElementos++;
				
			}
		}
		if (exito == false)
			System.out.println("No existe");
		else
			for (int i=0;i<nElementos;i++)
				System.out.println("Existe en Posicion "+posiciones[i]);
		
	}

}
