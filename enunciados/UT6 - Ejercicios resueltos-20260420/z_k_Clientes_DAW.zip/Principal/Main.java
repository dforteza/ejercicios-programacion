package Principal;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		RepositorioClientes repositorio = new RepositorioClientes(10);
		Scanner sc = new Scanner (System.in);
		int opcion;
		int codigo;
		Cliente cliente;
		boolean exito;
		do
		{
			opcion = menu(sc);
			switch (opcion)
			{
				case 1:
					Alta(repositorio,sc);
					break;
				case 2:
					Baja(repositorio,sc);
					break;
				case 3:
					Modificar(repositorio,sc);
					break;
				case 4:
					Buscar (repositorio,sc);
					break;
				case 5:
					System.out.println("La facturación total es");
					System.out.println(repositorio.facturacionTotal()); 
					break;
				case 6:
					System.out.println(repositorio);
					break;
				case 7:
				default:
			}
		} while (opcion!=7);
		sc.close();
	}
	
	
	public static void Alta(RepositorioClientes repositorio, Scanner sc)
	{
		boolean exito;
		exito = repositorio.alta(sc);
		if (exito==true)
			System.out.println("Alta realizada");
		else
			System.out.println("Repositorio lleno");
	}
	
	
	public static void Baja(RepositorioClientes repositorio, Scanner sc)
	{
		int codigo;
		boolean exito;
		System.out.println("Introduzca código a borrar");
		codigo = sc.nextInt();
		exito = repositorio.baja(codigo);
		if (exito == true)
			System.out.println("Baja realizada");
		else
			System.out.println("El cliente no existe");
	}
	
	public static void Modificar(RepositorioClientes repositorio, Scanner sc)
	{
		int codigo;
		boolean exito;
		System.out.println("Introduzca código del cliente");
		codigo = Integer.parseInt(sc.nextLine());
		
		exito = repositorio.modificarXCodigo(codigo, sc);
		if (exito==true)
			System.out.println("Modificación correcta");
		else
			System.out.println("El cliente no existe");
	}
	
	public static void Buscar (RepositorioClientes repositorio, Scanner sc)
	{
		int codigo;
		Cliente cliente;
		System.out.println("Introduzca código del cliente a buscar");
		codigo = sc.nextInt();
		cliente = repositorio.buscarXCodigo(codigo);
		if (cliente==null)
			System.out.println("El cliente no existe");
		else
			System.out.println(cliente);
	}
	
	public static int menu(Scanner sc)
	{
		int opcion;
		do
		{
			System.out.println("MENU PRINCIPAL");
			System.out.println("==============");
			System.out.println("1 - Alta de cliente");
			System.out.println("2 - Baja de cliente");
			System.out.println("3 - Modificar cliente");
			System.out.println("4 - Buscar cliente");
			System.out.println("5 - Estadísticas");
			System.out.println("6 - Listado de clientes");
			System.out.println("7 - Salir");
			System.out.println("Opcion:");
			try
			{
				opcion = sc.nextInt();
			}
			catch (InputMismatchException e)
			{
				opcion = 0;
			}
			sc.nextLine();
			if (opcion<1 || opcion>7)
				System.out.println("Opción incorrecta");
		} while (opcion<1 || opcion>7);
		return opcion;
	}
}





