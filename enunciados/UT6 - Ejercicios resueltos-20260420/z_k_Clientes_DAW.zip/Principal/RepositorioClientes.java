package Principal;

import java.util.Scanner;

public class RepositorioClientes 
{
	private Cliente vector[];
	private int nClientesActual;
	
	public RepositorioClientes (int nMaxClientes)
	{
		vector = new Cliente[nMaxClientes];
		nClientesActual = 0;
	}
	
	public boolean alta (Cliente c)
	{
		boolean exito = false;
		if (nClientesActual < vector.length) //(1) Verificar espacio
		{
			vector[nClientesActual] = c; // (2) Añadir cliente 
			nClientesActual++;	// (3) Incrementar nº clientes
			exito = true;
		}
		return exito;
	}
	
	public boolean alta (Scanner sc)
	{
		boolean exito=false;
		if (nClientesActual < vector.length)
			exito = alta(new Cliente(sc));
		return exito;
	}
	
	public Cliente buscarXCodigo (int codigo)
	{
		Cliente c = null;
		for (int i=0;i<nClientesActual;i++)
			if (vector [i].getCodigo() == codigo)
			{
				c = vector[i]; // return vector[i]
				break;
			}
		return c;
	}
	
	public boolean baja (int codigo)
	{
		boolean exito = false;
		for (int i=0;i<nClientesActual;i++)
			if (vector[i].getCodigo()==codigo)
			{
				for (int j=i;j<nClientesActual-1;j++)
					vector[j] = vector[j+1];
				exito = true;
				nClientesActual--;
				break; // i-- si existen más con el mismo código y los quieres borrar
			}
		return exito;
	}
	
	public boolean modificarXCodigo (int codigo,Scanner sc)
	{
		Cliente c;
		c = buscarXCodigo(codigo);
		if (c == null)
			return false;
		else
			c.modificarDatos(sc);
		return true;
	}
	
	public float facturacionTotal()
	{
		float total=0;
		for (int i=0;i<nClientesActual;i++)
			total += vector[i].getFacturacion();
		return total;
	}
	
	public String toString()
	{
		String resultado ="";
		if (this.nClientesActual==0)
			resultado += "Actualmente no hay clientes en la empresa";
		else
			for (int i=0;i<nClientesActual;i++)
				resultado += vector[i]+"\n\n";
		return resultado;
	}
}





