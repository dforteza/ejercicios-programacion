package Principal;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.Scanner;

enum Tipo {PARTICULAR,EMPRESA}
public class Cliente 
{
	private static int secuencia = 1;
	private int codigo; // Código único de cada cliente
	private String nombre;
	private Tipo tipo;
	private LocalDate fechaAlta;
	private float facturacion;
	
	public Cliente(String nombre, Tipo tipo, LocalDate fechaAlta, float facturacion) {
		super();
		this.codigo = secuencia++;
		this.nombre = nombre;
		this.tipo = tipo;
		this.fechaAlta = fechaAlta;
		this.facturacion = facturacion;
	}
	
	public Cliente(Scanner sc)
	{
		this.codigo = secuencia++;
		System.out.println("Nombre:");
		this.nombre = sc.nextLine();

		leerTipo(sc);
		leerFechaAlta(sc);

		System.out.println("Introduzca facturación");
		this.facturacion = Float.parseFloat(sc.nextLine());
	}

	public void leerTipo(Scanner sc)
	{
		boolean tipoOk;
		do
		{
			System.out.println("Tipo (EMPRESA ó PARTICULAR)");
			try
			{
				this.tipo = Tipo.valueOf(sc.nextLine().toUpperCase());
				tipoOk=true;
			}
			catch (IllegalArgumentException e)
			{
				tipoOk=false;
			}
		} while (tipoOk==false);
	}
	
	public void leerFechaAlta(Scanner sc)
	{
		boolean fechaOk;
		int dia,mes,anyo;
		String fechaCadena,tokens[]=null;
		do
		{
			try
			{
				fechaOk=true;
				System.out.println("Fecha (dd mm aaaa):");
				fechaCadena = sc.nextLine();
				tokens = fechaCadena.split("[ /-]+");
				if (tokens.length==3)
				{
					dia = Integer.parseInt(tokens[0]);
					mes = Integer.parseInt(tokens[1]);
					anyo = Integer.parseInt(tokens[2]);
					this.fechaAlta = LocalDate.of(anyo, mes, dia);
				}
				else
					System.out.println("Fecha incorrecta");
			} catch (DateTimeException e)
			{
				System.out.println("Formato o fecha incorrecta");
				fechaOk =false;
			}
		} while (tokens.length!=3 || fechaOk==false);
	}
	
	
	public void modificarDatos(Scanner sc)
	{
		String cadena;
		// Lectura del nombre
		System.out.println(nombre);
		System.out.println("Nuevo nombre");
		cadena = sc.nextLine();
		if (cadena.length()>0)
			nombre = cadena;
		// Lectura del tipo
		System.out.println(this.tipo);
		System.out.println("Nuevo tipo");
		cadena = sc.nextLine();
		if (cadena.length()>0)
			this.tipo = Tipo.valueOf(cadena.toUpperCase());
		
		// Lectura de la fecha
		System.out.println(this.fechaAlta);
		System.out.println("Nueva fecha");
		leerFechaAlta (sc);
		
		System.out.println(this.facturacion);
		System.out.println("Nueva facturación");
		cadena = sc.nextLine();
		if (cadena.length()>0)
			this.facturacion = Float.parseFloat(cadena);
	}
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Tipo getTipo() {
		return tipo;
	}

	public void setTipo(Tipo tipo) {
		this.tipo = tipo;
	}

	public LocalDate getFechaAlta() {
		return fechaAlta;
	}

	public void setFechaAlta(LocalDate fechaAlta) {
		this.fechaAlta = fechaAlta;
	}

	public float getFacturacion() {
		return facturacion;
	}

	public void setFacturacion(float facturacion) {
		this.facturacion = facturacion;
	}

	public int getCodigo() {
		return codigo;
	}
	
	public String toString()
	{
		String resultado ="";
		resultado += "Código:"+this.codigo;
		resultado += " Nombre:"+this.nombre;
		resultado += "\nFecha de Alta:";
		resultado += String.format(
				"%02d/%02d/%04d",
				this.fechaAlta.getDayOfMonth(),
				this.fechaAlta.getMonthValue(),
				this.fechaAlta.getYear());
		resultado += "\nTipo: "+this.tipo;
		resultado += " Facturación:"+this.facturacion;
		
		return resultado;
	}
}






