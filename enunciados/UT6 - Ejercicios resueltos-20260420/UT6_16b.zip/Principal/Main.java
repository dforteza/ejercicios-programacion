package Principal;

public class Main 
{
	public static void main(String[] args) 
	{
		int n = 5;
		char matriz[][] = new char[n][n];
		
		// Crear el contenido de la matriz
		
		for (int fila=0;fila<n;fila++)
			for (int columna=0;columna<n;columna++)
				if (fila==columna)
					matriz[fila][columna] = 'x';
				else
					if (fila+columna==n-1)
						matriz[fila][columna]='.';
					else
						if (fila>columna)
							matriz[fila][columna] = 'i';
						else
							if (fila<columna)
								matriz[fila][columna] = 's';
		
		
		// Imprimir la matriz
		for (int f=0;f<n;f++)
		{
			for (int c=0;c<n;c++)
				System.out.printf("%c",matriz[f][c]);
			System.out.println();
		}
	}

}
