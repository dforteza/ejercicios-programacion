package Principal;

public class Main {

	public static void main(String[] args) 
	{
		String texto = "A 1234-BCD B\n5678-DEF C 9999-ZZZ";
		String patronMatricula = "\\b\\d{4}-[BCDFGHJKLMNPRSTVWXYZ]{3}\\b";
		/* La variable patronMatricula contiene una expresión regular
		 * que representa una matrícula española en el formato 9999-XXX
		 */
		
		String alrededor = "(?=" + patronMatricula + ")|(?<=" + patronMatricula + ")";
		/* La variable alrededor contiene la expresión regular anterior 
		 * pero usa grupos y lookarounds 
		 * 	(?=...) es un lookahead positivo: “coincide si después de esta posición viene …”.
		 *  (?<=...) es un lookbehind positivo: “coincide si antes de esta posición está …”
		 *  Los () definen grupos y significa que no consume caracteres en el corte.
		 */
		
		/* En conjunto, la regex: (?=MATRICULA)|(?<=MATRICULA) 
		 * coincide en dos tipos de posiciones:
		 *  Justo antes de cada matrícula ((?=...)).
		 *	Justo después de cada matrícula ((?<=...)).
		 */
		
		String[] tokens = texto.split(alrededor);
		/* Con split y la expresión regular alrededor
		 * estás partiendo el texto antes y después de cada matrícula, sin eliminarla, 
		 * porque los lookarounds no consumen la matrícula.
		 */
		for (int i=0;i<tokens.length;i++) 
			if (tokens[i].matches(patronMatricula)) //Eliminamos lo que no son matrículas
				System.out.println(tokens[i]);
	}
}
