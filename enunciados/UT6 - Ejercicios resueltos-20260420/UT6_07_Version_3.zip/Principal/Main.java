package Principal;

import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		String cadena;
		String resultado ="";
		String tokens[];
		System.out.println("Introduzca una frase");
		cadena = sc.nextLine();
		
		tokens = cadena.split(" ");
		for (int i=0;i<tokens.length;i++)
			resultado += tokens[i].charAt(0);
		
		System.out.println(resultado);
		sc.close();
	}
}
