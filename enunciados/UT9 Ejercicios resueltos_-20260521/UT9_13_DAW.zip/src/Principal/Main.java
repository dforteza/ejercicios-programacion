package Principal;

import java.io.IOException;
import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws IOException 
	{
		Scanner sc = new Scanner (System.in);
		int opcion;
		Repositorio r = new Repositorio();
		try
		{
			r.recuperarV2("puntos.dat");
		} catch (ClassNotFoundException | IOException e) {
			System.out.println("No había datos iniciales");
		}
		do
		{
			opcion = menu(sc);
			switch (opcion)
			{
			case 1:
				altaPuntuacion(sc,r);
				r.guardarV2("puntos.dat");
				break;
			case 2:
				r.ordenar();
				System.out.println(r);
				break;
			case 3:
				r.exportar("puntos"+LocalDate.now()+".csv");
				break;
			case 4:
				r.importar("datos.txt");
				break;
			}
		} while (opcion!=5);
		
		sc.close();
	}
	
	public static void altaPuntuacion (Scanner sc,Repositorio r)
	{
		Puntuacion p;
		p= new Puntuacion();
		System.out.println("Introduzca el nombre:");
		p.setNombre(sc.nextLine());
		System.out.println("Introduzca los puntos");
		p.setPuntos(Integer.parseInt(sc.nextLine()));
		r.alta(p);
	}
	
	public static int menu(Scanner sc)
	{
		int opcion;
		do
		{
			System.out.println("1 - Alta de puntuación");
			System.out.println("2 - Listado de puntuación");
			System.out.println("3 - Exportar.");
			System.out.println("4 - Importar");
			System.out.println("5 - Salir");
			System.out.println("Opción:");
			try {
				opcion = sc.nextInt();
			} catch (InputMismatchException e) {opcion=0;}
			sc.nextLine();
			if (opcion<1 || opcion>5)
				System.out.println("Opción incorrecta");
		} while (opcion<1 || opcion>5);
		return opcion;
	}
}
