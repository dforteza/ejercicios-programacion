package Principal;

import java.io.IOException;

public class Main 
{
	public static void main(String[] args) throws IOException 
	{
		Procesar p = new Procesar ("Mensaje.txt");
		
		System.out.println("El fichero tiene");
		System.out.println("\t"+p.caracteres()+" characteres");
		System.out.println("\t"+p.lineas()+" lineas.");
		System.out.println("\t"+p.palabras()+" palabras");
	}

}
