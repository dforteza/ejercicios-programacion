package Principal;

import java.io.File;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) 
	{
		File directorio;
		File listado[];
		int contadorArchivos = 0;
		int contadorDirectorios = 0;
		String nombreDirectorio;
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduzca ruta a una carpeta:");
		nombreDirectorio = sc.nextLine();
		
		directorio = new File(nombreDirectorio);
		if (directorio.exists())
		{
			System.out.println("Existe");
			if (directorio.isDirectory())
			{
				System.out.println("Es un directorio");
				listado = directorio.listFiles();
				for (File f :listado)
					if (f.isDirectory())
					{
						System.out.println("Directorio: "+f.getName());
						contadorDirectorios++;
					}
					else
					{
						System.out.println("Fichero: "+f.getName());
						contadorArchivos++;
					}
				System.out.println("Hay "+contadorDirectorios+" directorios.");
				System.out.println("Hay "+contadorArchivos+" ficheros.");
			}
			else
				System.out.println("Es un fichero");
		}
		else
			System.out.println("No existe");
		
		
		
		sc.close();
	}

}
