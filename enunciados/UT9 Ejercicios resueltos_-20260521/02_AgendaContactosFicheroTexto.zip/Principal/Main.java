package Principal;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner (System.in);
		int opcion;
		Agenda agenda = new Agenda();
		Contacto c;
		try {
			agenda.recuperar();
		} catch (IOException e) {
			System.out.println("No hay agenda previa");
		}
		do
		{
			opcion = menu(sc);
			switch (opcion)
			{
			case 1:
				c = new Contacto();
				System.out.println("Nombre:");
				c.setNombre(sc.nextLine());
				System.out.println("Telefono:");
				c.setTelefono(sc.nextLine());
				System.out.println("Edad:");
				c.setEdad(Integer.parseInt(sc.nextLine()));
				System.out.println("Salario:");
				c.setSalario(Double.parseDouble(sc.nextLine()));
				if (agenda.alta(c))
				{
					try {
						agenda.guardar();
					} catch (IOException e) {
						System.out.println("Atención: No se ha podido guardar el contacto en disco");
					}
					System.out.println("Se ha dado de alta el contacto");
				}
				else
					System.out.println("No se ha podido dar de alta el contacto");
				break;
			case 2:
				System.out.println(agenda);
				break;
			case 3: 
				try {
					agenda.guardar();
				} catch (IOException e) 
				{
					System.out.println("No se ha podido guardar la agenda");
					e.printStackTrace();
				}
				break;
			}
		} while (opcion!=3);
		sc.close();
	}

	public static int menu(Scanner sc)
	{
		int opcion;
		do
		{
			System.out.println("MENU DE OPCIONES");
			System.out.println("================");
			System.out.println("1 - Alta de contacto");
			System.out.println("2 - Ver contactos");
			System.out.println("3 - Salir");
			System.out.println("Opcion:");
			try { opcion = sc.nextInt();}
			catch (InputMismatchException e) {opcion = 0;}
			sc.nextLine();
			if (opcion<1 || opcion>3)
				System.out.println("opcion incorrecta");
		} while (opcion<1 || opcion>3);
		return opcion;
	}
}
