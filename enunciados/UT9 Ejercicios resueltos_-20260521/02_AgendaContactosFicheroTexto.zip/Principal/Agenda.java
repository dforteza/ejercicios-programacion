package Principal;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Agenda 
{
	private List<Contacto> lista;
	
	public Agenda()
	{
		this.lista = new ArrayList<>();
	}
	
	public boolean alta(Contacto c)
	{
		return lista.add(c);
	}
	
	public void recuperar() throws IOException
	{
		FileReader fr = new FileReader("Agenda.txt");
		Scanner entrada = new Scanner(fr);
		Contacto c;
		while (entrada.hasNextLine())
		{
			c= new Contacto();
			c.setNombre(entrada.nextLine());
			c.setTelefono(entrada.nextLine());
			c.setEdad(Integer.parseInt(entrada.nextLine()));
			c.setSalario(Double.parseDouble(entrada.nextLine()));
			alta(c);
		}
		entrada.close();
		fr.close();
	}
	public void guardar() throws IOException
	{
		FileWriter fw = new FileWriter("Agenda.txt");
		PrintWriter salida = new PrintWriter(fw);
		for (Contacto c:lista)
		{
			salida.println(c.getNombre());
			salida.println(c.getTelefono());
			salida.println(c.getEdad());
			salida.println(c.getSalario());
		}
		salida.close();
		fw.close();
	}
	
	public String toString()
	{
		String resultado ="";
		resultado += "AGENDA DE CONTACTOS\n";
		resultado += "===================\n";
		for (Contacto c:lista)
			resultado += c+"\n";
		return resultado;
	}
}