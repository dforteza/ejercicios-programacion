package Principal;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Repositorio 
{
	private List<Puntuacion> lista;
	
	
	public Repositorio()
	{
		lista = new ArrayList<>();
	}
	
	public Iterator<Puntuacion> getIterator()
	{
		return lista.iterator();
	}
	
	public void ordenar()
	{
		lista.sort(null);
	}
	
	public boolean alta(Puntuacion p)
	{
		return lista.add(p);
	}
	
	public boolean baja(Puntuacion p)
	{
		return lista.remove(p);
	}

	public void guardarV1 (String nombreFichero) throws IOException
	{
		FileOutputStream fos = new FileOutputStream(nombreFichero);
		DataOutputStream salida = new DataOutputStream(fos);
		for (Puntuacion p:lista)
		{
			salida.writeUTF(p.getNombre());
			salida.writeInt(p.getPuntos());
		}
		salida.close();
		fos.close();
	}
	public void guardarV2 (String nombreFichero) throws IOException
	{
		FileOutputStream fos = new FileOutputStream(nombreFichero);
		ObjectOutputStream salida = new ObjectOutputStream(fos);
		for (Puntuacion p: lista) // salida.writeObject(lista);
			salida.writeObject(p);
		salida.close();
		fos.close();
	}
	
	public void recuperarV1 (String nombreFichero) throws IOException
	{
		FileInputStream fis = new FileInputStream(nombreFichero);
		DataInputStream entrada = new DataInputStream(fis);
		Puntuacion p;
		while (true)
		{
			try {
				p = new Puntuacion();
				p.setNombre(entrada.readUTF());
				p.setPuntos(entrada.readInt());
				lista.add(p);
			} catch (EOFException e)
			{ break;}
		}
		entrada.close();
		fis.close();
	}
	public void recuperarV2 (String nombreFichero) throws IOException, ClassNotFoundException
	{
		FileInputStream fis = new FileInputStream(nombreFichero);
		ObjectInputStream entrada = new ObjectInputStream(fis);
		while (true)
		{
			try {
			lista.add((Puntuacion)entrada.readObject());
			} catch (EOFException e)
			{ break;}
		}
		entrada.close();
		fis.close();
	}
	
	public void exportar(String nombreFichero) throws IOException
	{
		FileWriter fw = new FileWriter(nombreFichero);
		PrintWriter salida = new PrintWriter(fw);
		for (Puntuacion p: lista)
			salida.println (p.getNombre()+";"+p.getPuntos());
		salida.close();
		fw.close();
	}
	
	public void importar (String nombreFichero) throws IOException
	{
		FileReader fr = new FileReader(nombreFichero);
		Scanner entrada = new Scanner(fr);
		String linea;
		String tokens[];
		Puntuacion p;
		 while (entrada.hasNextLine())
		 {
			 linea = entrada.nextLine();
			 tokens = linea.split(";");
			 p = new Puntuacion();
			 p.setNombre(tokens[0]);
			 p.setPuntos(Integer.parseInt(tokens[1]));
			 lista.add(p);
		 }
		entrada.close();
		fr.close();
	}
	
	
	public String toString()
	{
		String resultado="";
		resultado += "LISTADO PUNTUACIONES\n";
		resultado += "====================\n";
		for (Puntuacion p:lista)
			resultado += p+"\n";
		return resultado;
	}
}
