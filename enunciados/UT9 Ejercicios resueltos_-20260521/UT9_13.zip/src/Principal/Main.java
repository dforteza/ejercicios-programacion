package Principal;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		Repositorio r = new Repositorio();

		try {
			r.recuperarV2("puntos.dat");
		} catch (ClassNotFoundException | IOException e) 
		{
			System.out.println("No hay datos previos.");
		}
		
		int opcion;
		do
		{
			opcion = menu(sc);
			switch (opcion)
			{
			case 1:
				nuevaPuntuacion(sc,r);
				try {
					r.guardarV2("puntos.dat");
				} catch (IOException e) {
					System.out.println("Los datos no se han actualizado");
				}
				break;
			case 2:
				bajaPuntuacion(sc,r);
				try {
					r.guardarV2("puntos.dat");
				} catch (IOException e) {
					System.out.println("Los datos no se han actualizado");				}
				break;
			case 3:
				r.ordenar();
				System.out.println(r);
				break;
			case 4:
				try {
					r.importar("ficheroExterno.txt");
				} catch (IOException e) {
				System.out.println("El fichero no existe");
				}
				break;
			case 5:
				try 
				{
					r.exportar("puntos.txt");
				} catch (IOException e) 
				{
					e.printStackTrace();
				}
				break;
			}
		} while (opcion!=6);
		
		sc.close();
	}
	
	public static void nuevaPuntuacion(Scanner sc, Repositorio r)
	{
		Puntuacion p;
		p = new Puntuacion();
		System.out.println("Introduzca nombre:");
		p.setNombre(sc.nextLine());
		System.out.println("Introduzca puntos");
		p.setPuntos(sc.nextInt());
		sc.nextLine();
		r.alta(p);
	}
	
	public static void bajaPuntuacion(Scanner sc,Repositorio r)
	{
		String nombre;
		Iterator<Puntuacion> it;
		Puntuacion p;
		System.out.println("Introduzca nombre a buscar:");
		nombre = sc.nextLine();
		it = r.getIterator();
		while (it.hasNext())
		{
			p = it.next();
			if (nombre.equals(p.getNombre()))
				it.remove();
		}
	}
	
	public static int menu(Scanner sc)
	{
		int opcion;
		do
		{
			System.out.println("Menú de opciones");
			System.out.println("================");
			System.out.println("1 - Alta puntuación.");
			System.out.println("2 - Baja x nombre puntuación.");
			System.out.println("3 - Listado puntuaciones.");
			System.out.println("4 - Importar puntuaciones");
			System.out.println("5 - Exportar puntuaciones");
			System.out.println("6 - Salir");
			System.out.println("Opción:");
			try {opcion = sc.nextInt();}
			catch (InputMismatchException e) {opcion = 0;}
			sc.nextLine();
			if (opcion<1 || opcion>6)
				System.out.println("Opción incorrecta");
		} while (opcion<1 || opcion>6);
		return opcion;
	}
}
 