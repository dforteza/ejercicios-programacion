package Principal;

import java.io.Serializable;

public class Puntuacion implements Comparable<Puntuacion>,Serializable 
{
	private static final long serialVersionUID = 1L;
	private String nombre;
	private int puntos;
	
	public Puntuacion()
	{
		
	}
	
	public Puntuacion(String nombre, int puntos) {
		super();
		this.nombre = nombre;
		this.puntos = puntos;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getPuntos() {
		return puntos;
	}

	public void setPuntos(int puntos) {
		this.puntos = puntos;
	}

	@Override
	public String toString() {
		return nombre + " ->" + puntos;
	}

	@Override
	public int compareTo(Puntuacion o) 
	{
		if (puntos==o.puntos)
			return nombre.compareTo(o.nombre);
		else
			return Integer.compare(puntos, o.puntos);
	}
}
