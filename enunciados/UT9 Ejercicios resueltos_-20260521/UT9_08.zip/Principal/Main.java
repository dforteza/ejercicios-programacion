package Principal;

import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException {
	Criptografia c = new Criptografia (2);
	
	//c.encriptar("texto");
	c.desencriptar("texto");
	}

}
