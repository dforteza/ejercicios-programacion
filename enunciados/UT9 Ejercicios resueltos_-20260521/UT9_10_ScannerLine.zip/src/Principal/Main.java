package Principal;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) throws IOException 
	{
		FileReader fr = new FileReader("alumnos_notas.txt");
		Scanner entrada = new Scanner(fr);
		String linea;
		Alumno a=null;
		List<Alumno> listado = new ArrayList<>();
		
		while (entrada.hasNextLine())
		{
			linea = entrada.nextLine(); // Leo un alumno completo
			Scanner sc = new Scanner (linea).useLocale(Locale.US);
			int secuencia = 0;
			while (sc.hasNext())
			{
				if (sc.hasNextDouble())
					a.addNota(sc.nextDouble());
				else
				{
					switch (secuencia)
					{
					case 0: a = new Alumno (sc.next()); break;
					case 1: a.setApellido1(sc.next());break;
					case 2: a.setApellido2(sc.next());break;
					default: sc.next();break;
					}
					secuencia++;
				}
			}
			a.calcularMedia();
			listado.add(a);
			sc.close();
		}
		entrada.close();
		fr.close();
		
		listado.sort(null);
		
		for (Alumno alumno: listado)
			System.out.println(alumno);
	}
}
