package Principal;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class StopComentarios 
{
	private String nombreFicheroEntrada;
	private String nombreFicheroSalida;
	
	public StopComentarios(String fi,String fo) throws IOException
	{
		this.nombreFicheroEntrada = fi;
		this.nombreFicheroSalida = fo;
		procesar();
	}
	
	private void procesar() throws IOException
	{
		FileReader entrada = new FileReader(nombreFicheroEntrada);
		FileWriter salida = new FileWriter(nombreFicheroSalida);
		int c;
		int estado=0;
		while ((c=entrada.read())!=-1)
		{
			switch(estado)
			{
			case 0:
				if ((char)c=='/')
					estado = 1;
				else
				{
					salida.write(c);
					if ((char)c=='"')
						estado = 5;
				}
				break;
			case 1:
				if ((char)c=='/')
					estado=2;
				else
					if ((char)c=='*')
						estado=3;
					else
					{
						estado=0;
						salida.write('/');
						salida.write(c);
					}
				break;
			case 2:
				if ((char)c=='\n')
				{
					estado = 0;
					salida.write(c);
				}
				break;
			case 3:
				if ((char)c=='*')
					estado = 4;
				break;
			case 4:
				if ((char)c=='/')
					estado = 0;
				else
					if ((char)c!='*')
						estado = 3;
				break;
			case 5:
				salida.write(c);
				if ((char)c =='"')
					estado = 0;
				break;
			}
		}
		entrada.close();
		salida.close();
	}
}
