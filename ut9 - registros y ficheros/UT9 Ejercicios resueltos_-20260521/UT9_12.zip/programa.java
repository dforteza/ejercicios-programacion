package Principal;
// Esto es un comentario
/* Esto es un comentario
de varias lineas
*/
public class Main 
{
	/** Comentario tipo javadoc
	* con varias líneas
	**/ 
	public static void main(String[] args) // Esto es otro comentario
	{
		int a = 5/6;
		System.out.println ("Hola //Esto es un comentario");
	}
}
