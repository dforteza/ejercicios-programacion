package Principal;

import java.io.File;
import java.io.IOException;

public class Main 
{
	public static void main(String[] args) throws IOException, InterruptedException 
	{
		File fichero = new File("datos.txt");
		File informacion = new File("informacion.txt");
		if (fichero.exists())
		{
			System.out.println("Existe");
			fichero.renameTo(informacion);
			Thread.sleep(3000);
			informacion.delete();
		}
		
		else
		{
			System.out.println("No existe, lo voy a crear");
			fichero.createNewFile();
		}
	}

}
