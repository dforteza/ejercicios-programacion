package Principal;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) throws IOException 
	{
		FileReader fr = new FileReader("alumnos_notas.txt");
		Scanner entrada = new Scanner(fr);
		String linea;
		String tokens[]; // Vector de Cadenas
		Alumno a;
		List<Alumno> listado = new ArrayList<>();
		while (entrada.hasNextLine())
		{
			linea = entrada.nextLine(); // Leo un alumno completo
			tokens = linea.split(" ");
			a = new Alumno(tokens[0]);
			a.setApellido1(tokens[1]);
			a.setApellido2(tokens[2]);
			for (int i=3;i<tokens.length;i++)
				a.addNota(Double.parseDouble(tokens[i]));
			a.calcularMedia();
			listado.add(a);
		}
		entrada.close();
		fr.close();
		
		listado.sort(null);
		
		for (Alumno alumno: listado)
			System.out.println(alumno);
	}
}
