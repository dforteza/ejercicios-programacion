package Principal;

import java.util.ArrayList;
import java.util.List;

public class Alumno implements Comparable<Alumno>
{
	private String nombre;
	private String apellido1;
	private String apellido2;
	private List<Double> notas;
	private double media;
	
	public Alumno (String nombre)
	{
		this.nombre = nombre;
		this.notas = new ArrayList<>();
	}
	
	public void setApellido1(String apellido1) {
		this.apellido1 = apellido1;
	}

	public void setApellido2(String apellido2) {
		this.apellido2 = apellido2;
	}

	public void addNota(double nota)
	{
		this.notas.add(nota);
	}

	public void calcularMedia()
	{
		double suma = 0;
		for (Double d:notas)
			suma += d;
		media = suma/notas.size();
	}
	
	public String toString()
	{
		String resultado ="";
		resultado += nombre+" "+apellido1+" "+apellido2;
		for (Double d:notas)
			resultado += String.format(" %.2f",d);
		resultado += " Media: "+String.format ("%.2f",media);
		return resultado;
	}

	@Override
	public int compareTo(Alumno o) 
	{
		int resultado;
		boolean c1 = this.apellido1.equals(o.apellido1);
		boolean c2 = this.apellido2.equals(o.apellido2);
		if (c1)
		{
			if (c2)
				resultado = this.nombre.compareTo(o.nombre);
			else
				resultado = this.apellido2.compareTo(o.apellido2);
		}
		else
			resultado = this.apellido1.compareTo(o.apellido1);
		return resultado;
	}
}







